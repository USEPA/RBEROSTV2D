#STmodel_seasonal.mod
      
set comid_all :=
{'23963049','23963051','23963053','23963055','23963057','23963059','23963061','23963063','23963065','23963067','23963069','23963071','23963073','23963075','23963077','23963081','23963083','23963085','23963087','23963089','23963091','23963093','23963095','23963097','23963099','23963101','23963103','23963105','23963109','23963111','23963113','23963115','23963117','23963119','23963121','23963123','23963125','23963127','23963129','23963131','23963133','23963135','23963137','23963139','23963141','23963143','23963145','23963147','23963149','23963151','23963153','23963155','23963157','23963159','23963161','23963163','23963165','23963167','23963169','23963171','23963173','23963175','23963177','23963179','23963181','23963183','23963185','23963187','23963189','23963191','23963193','23963195','23963197','23963199','23963201','23963203','23963205','23963207','23963209','23963211','23963213','23963215','23963217','23963219','23963221','23963223','23963225','23963227','23963229','23963231','23963233','23963235','23963237','23963239','23963241','23963243','23963245','23963247','23963249','23963251','23963253','23963255','23963257','23963259','23963261','23963263','23963265','23963267','23963269','23963271','23963273','23963275','23963277','23963279','23963281','23963283','23963285','23963287','23963289','23963291','23963293','23963295','23963297','23963299','23963301','23963303','23963305','23963307','23963309','23963311','23963313','23963315','23963317','23963319','23963321','23963323','23963325','23963327','23963329','23963331','23963333','23963335','23963337','23963339','23963341','23963343','23963345','23963347','23963349','23963351','23963353','23963355','23963357','23963359','23963361','23963363','23963365','23963367','23963369','23963371','23963373','23963375','23963377','23963379','23963381','23963383','23963385','23963387','23963389','23963391','23963393','23963395','23963397','23963399','23963401','23963403','23963405','23963407','23963409','23963411','23963413','23963415','23963417','23963419','23963421','23963423','23963425','23963427','23963429','23963431','23963433','23963435','23963437','23963439','23963441','23963443','23963445','23963447','23963807','23963815','23963817','23963819','23963821','23963823','23963825','23963827','23963833','23963841','23963843','23963845','23963847','23963849','23963851','23963853','23963855','23963857','23964179','23964217','23964229','23964231','23964233','23964251','23964257','23964263','23964267','23964269','23964275','23964277','23964281','23964283','23964285','23964287','23964291','23964293','23964295','23964297','23964299','23964301','23964305','23964307','23964309','23964311','23964313','23964315','23964317','23964319','23964321','23964323','23964325','23964327','23964329','23964331','23964333','23964335','23964337','23964339','23964341','23964345','23964347','23964349','23964351','23964353','23964355','23964357','23964359','23964363','23964365','23964367','23964369','23964371','23964373','23964375','23964377','23964379','23964381','23964383','23964385','23964387','23964389','23964391','23964393','23964395','23964397','23964399','23964401','23964405','23964407','23964409','23964411','23964413','23964415','23964417','23964419','23964421','23964423','23964425','23964427','23964429','23964431','23964433','23964435','23964437','23964439','23964441','23964443','23964445','23964447','23964449','23964451','23964453','23964455','23964457','23964459','23964461','23964463','23964465','23964467','23964469','23964471','23964473','23964475','23964477','23964479','23964481','23964483','23964485','23964487','23964489','23964491','23964493','23964495','23964497','23964499','23964501','23964503','23964505','23964507','23964509','23964511','23964513','23964515','23964517','23964519','23964521','23964523','23964525','23964527','23964529','23964531','23964533','23964535','23964537','23964539','23964541','23964543','23964545','23964547','23964549','23964551','23964553','23964555','23964557','23964559','23964561','23964563','23964565','23964567','23964569','23964571','23964573','23964575','23964577','23964579','23964581','23964583','23964585','23964587','23964589','23964591','23964593','23964595','23964597','23964599','23964601','23964603','23964605','23964607','23964609','23964611','23964613','23964615','23964617','23964619','23964621','23964623','23964625','23964627','23964629','23964631','23964633','23964635','23964637','23964639','23964641','23964643','23964645','23964647','23964649','23964651','23964653','23964655','23964657','23964659','23964661','23964663','23964665','23964695','23964697','23964703','23964705','23964707','23964709','23964711','23964713','23964715','23964717','23964719','23964721','23964723','23964725','23964727','23964729','23964731','23964733','23964735','23964737','23964739','23964741','23964743','23964745','23964747','23964749','23964751','23964753','23964755','23964757','23964759','23964761','23964763','23964765','23964797','23964799','23964801','23964803','23964813','23964817','23964819','23964821','23964823','23964825','23964827','23964829','23964831','23964833','23964839','23964841','23964845','23964847','23964849','23965045','23965047','23965055','23965057','23965059'};

set comid_all_N within comid_all := {'23963049','23963051','23963053','23963055','23963057','23963059','23963061','23963063','23963065','23963067','23963069','23963071','23963073','23963075','23963077','23963081','23963083','23963085','23963087','23963089','23963091','23963093','23963095','23963097','23963099','23963101','23963103','23963105','23963109','23963111','23963113','23963115','23963117','23963119','23963121','23963123','23963125','23963127','23963129','23963131','23963133','23963135','23963137','23963139','23963141','23963143','23963145','23963147','23963149','23963151','23963153','23963155','23963157','23963159','23963161','23963163','23963165','23963167','23963169','23963171','23963173','23963175','23963177','23963179','23963181','23963183','23963185','23963187','23963189','23963191','23963193','23963195','23963197','23963199','23963201','23963203','23963205','23963207','23963209','23963211','23963213','23963215','23963217','23963219','23963221','23963223','23963225','23963227','23963229','23963231','23963233','23963235','23963237','23963239','23963241','23963243','23963245','23963247','23963249','23963251','23963253','23963255','23963257','23963259','23963261','23963263','23963265','23963267','23963269','23963271','23963273','23963275','23963277','23963279','23963281','23963283','23963285','23963287','23963289','23963291','23963293','23963295','23963297','23963299','23963301','23963303','23963305','23963307','23963309','23963311','23963313','23963315','23963317','23963319','23963321','23963323','23963325','23963327','23963329','23963331','23963333','23963335','23963337','23963339','23963341','23963343','23963345','23963347','23963349','23963351','23963353','23963355','23963357','23963359','23963361','23963363','23963365','23963367','23963369','23963371','23963373','23963375','23963377','23963379','23963381','23963383','23963385','23963387','23963389','23963391','23963393','23963395','23963397','23963399','23963401','23963403','23963405','23963407','23963409','23963411','23963413','23963415','23963417','23963419','23963421','23963423','23963425','23963427','23963429','23963431','23963433','23963435','23963437','23963439','23963441','23963443','23963445','23963447','23963807','23963815','23963817','23963819','23963821','23963823','23963825','23963827','23963833','23963841','23963843','23963845','23963847','23963849','23963851','23963853','23963855','23963857','23964179','23964217','23964229','23964231','23964233','23964251','23964257','23964263','23964267','23964269','23964275','23964277','23964281','23964283','23964285','23964287','23964291','23964293','23964295','23964297','23964299','23964301','23964305','23964307','23964309','23964311','23964313','23964315','23964317','23964319','23964321','23964323','23964325','23964327','23964329','23964331','23964333','23964335','23964337','23964339','23964341','23964345','23964347','23964349','23964351','23964353','23964355','23964357','23964359','23964363','23964365','23964367','23964369','23964371','23964373','23964375','23964377','23964379','23964381','23964383','23964385','23964387','23964389','23964391','23964393','23964395','23964397','23964399','23964401','23964405','23964407','23964409','23964411','23964413','23964415','23964417','23964419','23964421','23964423','23964425','23964427','23964429','23964431','23964433','23964435','23964437','23964439','23964441','23964443','23964445','23964447','23964449','23964451','23964453','23964455','23964457','23964459','23964461','23964463','23964465','23964467','23964469','23964471','23964473','23964475','23964477','23964479','23964481','23964483','23964485','23964487','23964489','23964491','23964493','23964495','23964497','23964499','23964501','23964503','23964505','23964507','23964509','23964511','23964513','23964515','23964517','23964519','23964521','23964523','23964525','23964527','23964529','23964531','23964533','23964535','23964537','23964539','23964541','23964543','23964545','23964547','23964549','23964551','23964553','23964555','23964557','23964559','23964561','23964563','23964565','23964567','23964569','23964571','23964573','23964575','23964577','23964579','23964581','23964583','23964585','23964587','23964589','23964591','23964593','23964595','23964597','23964599','23964601','23964603','23964605','23964607','23964609','23964611','23964613','23964615','23964617','23964619','23964621','23964623','23964625','23964627','23964629','23964631','23964633','23964635','23964637','23964639','23964641','23964643','23964645','23964647','23964649','23964651','23964653','23964655','23964657','23964659','23964661','23964663','23964665','23964695','23964697','23964703','23964705','23964707','23964709','23964711','23964713','23964715','23964717','23964719','23964721','23964723','23964725','23964727','23964729','23964731','23964733','23964735','23964737','23964739','23964741','23964743','23964745','23964747','23964749','23964751','23964753','23964755','23964757','23964759','23964761','23964763','23964765','23964797','23964799','23964801','23964803','23964813','23964817','23964819','23964821','23964823','23964825','23964827','23964829','23964831','23964833','23964839','23964841','23964845','23964847','23964849','23965045','23965047','23965055','23965057','23965059'};

set comid_all_P within comid_all := {};

set comid_N1 within comid_all_N := {'23963049','23963051','23963053','23963055','23963057','23963059','23963061','23963063','23963065','23963067','23963069','23963071','23963073','23963075','23963077','23963081','23963083','23963085','23963087','23963089','23963091','23963093','23963095','23963097','23963099','23963101','23963103','23963105','23963109','23963111','23963113','23963115','23963117','23963119','23963121','23963123','23963125','23963127','23963129','23963131','23963133','23963135','23963137','23963139','23963141','23963143','23963145','23963147','23963149','23963151','23963153','23963155','23963157','23963159','23963161','23963163','23963165','23963167','23963169','23963171','23963173','23963175','23963177','23963179','23963181','23963183','23963185','23963187','23963189','23963191','23963193','23963195','23963197','23963199','23963201','23963203','23963205','23963207','23963209','23963211','23963213','23963215','23963217','23963219','23963221','23963223','23963225','23963227','23963229','23963231','23963233','23963235','23963237','23963239','23963241','23963243','23963245','23963247','23963249','23963251','23963253','23963255','23963257','23963259','23963261','23963263','23963265','23963267','23963269','23963271','23963273','23963275','23963277','23963279','23963281','23963283','23963285','23963287','23963289','23963291','23963293','23963295','23963297','23963299','23963301','23963303','23963305','23963307','23963309','23963311','23963313','23963315','23963317','23963319','23963321','23963323','23963325','23963327','23963329','23963331','23963333','23963335','23963337','23963339','23963341','23963343','23963345','23963347','23963349','23963351','23963353','23963355','23963357','23963359','23963361','23963363','23963365','23963367','23963369','23963371','23963373','23963375','23963377','23963379','23963381','23963383','23963385','23963387','23963389','23963391','23963393','23963395','23963397','23963399','23963401','23963403','23963405','23963407','23963409','23963411','23963413','23963415','23963417','23963419','23963421','23963423','23963425','23963427','23963429','23963431','23963433','23963435','23963437','23963439','23963441','23963443','23963445','23963447','23963807','23963815','23963817','23963819','23963821','23963823','23963825','23963827','23963833','23963841','23963843','23963845','23963847','23963849','23963851','23963853','23963855','23963857','23964179','23964217','23964229','23964231','23964233','23964251','23964257','23964263','23964267','23964269','23964275','23964277','23964281','23964283','23964285','23964287','23964291','23964293','23964295','23964297','23964299','23964301','23964305','23964307','23964309','23964311','23964313','23964315','23964317','23964319','23964321','23964323','23964325','23964327','23964329','23964331','23964333','23964335','23964337','23964339','23964341','23964345','23964347','23964349','23964351','23964353','23964355','23964357','23964359','23964363','23964365','23964367','23964369','23964371','23964373','23964375','23964377','23964379','23964381','23964383','23964385','23964387','23964389','23964391','23964393','23964395','23964397','23964399','23964401','23964405','23964407','23964409','23964411','23964413','23964415','23964417','23964419','23964421','23964423','23964425','23964427','23964429','23964431','23964433','23964435','23964437','23964439','23964441','23964443','23964445','23964447','23964449','23964451','23964453','23964455','23964457','23964459','23964461','23964463','23964465','23964467','23964469','23964471','23964473','23964475','23964477','23964479','23964481','23964483','23964485','23964487','23964489','23964491','23964493','23964495','23964497','23964499','23964501','23964503','23964505','23964507','23964509','23964511','23964513','23964515','23964517','23964519','23964521','23964523','23964525','23964527','23964529','23964531','23964533','23964535','23964537','23964539','23964541','23964543','23964545','23964547','23964549','23964551','23964553','23964555','23964557','23964559','23964561','23964563','23964565','23964567','23964569','23964571','23964573','23964575','23964577','23964579','23964581','23964583','23964585','23964587','23964589','23964591','23964593','23964595','23964597','23964599','23964601','23964603','23964605','23964607','23964609','23964611','23964613','23964615','23964617','23964619','23964621','23964623','23964625','23964627','23964629','23964631','23964633','23964635','23964637','23964639','23964641','23964643','23964645','23964647','23964649','23964651','23964653','23964655','23964657','23964659','23964661','23964663','23964665','23964695','23964697','23964703','23964705','23964707','23964709','23964711','23964713','23964715','23964717','23964719','23964721','23964723','23964725','23964727','23964729','23964731','23964733','23964735','23964737','23964739','23964741','23964743','23964745','23964747','23964749','23964751','23964753','23964755','23964757','23964759','23964761','23964763','23964765','23964797','23964799','23964801','23964803','23964813','23964817','23964819','23964821','23964823','23964825','23964827','23964829','23964831','23964833','23964839','23964841','23964845','23964847','23964849','23965045','23965047','23965055','23965057','23965059'};

set comid_P1 within comid_all_P := {};

set seasons := 1..4 ordered; 

set years := 6..7 ordered;

set urban_land_uses := {'UIDU','URHD','URLD','URMD'};

set urban_soil_groups := {'A','B','C','D'};

set road_soil_groups := {'A','B','C','D'};


set urban_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Green_Roof','Infiltration_Basin','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set urban_pervbmp within urban_bmp :=
{'Porous_Pavement_w_UD'};

set road_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Infiltration_Basin','Infiltration_Chamber','Infiltration_Trench','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set ag_bmp :=
{'Conservation','Contour_Farming','Fert_75','Fert_90','Filterstrip','MIN_TILL','Terrace_Waterway','Terrace_Only','Waterway_Only','Grade_Stabilization','Diversion','Cover_Crops','Drainage_Management','Manure_Injection'};

set ag_tilebmp within ag_bmp :=
{'Drainage_Management'};

set septic_bmp :=
{'none'};

set graz_bmp :=
{'Offsite_Water'};

set ripbuf_bmp :=
{'Grassed_Buffer','Forested_Buffer'};

set point_bmp :=
{'C','C_F','FOURBDP_M','FOURBDP_M_C_F','MLE','MLE_C','C_M','M','SBR','SBR_C','SBR_C_F','SBR_DNF_C_F_M','SBR_DNF_M','FOURBDP_MBR_M','FOURBDP_MBR_M_C','MLE_MBR','MLE_MBR_C'};

set loads_all :=
{'point', 'urban', 'road', 'ag', 'septic', 'graz', 'storage', 'other'};
  
set area_sub :=
{'ag', 'graz'};
set urban_area_sub :=
{'urban'};
set road_area_sub :=
{'road'};

set transfer_types := {'coeff', 'notrib'};

set loads_riparian := 
 {'riparian'};

set limits := 
 {'limits'};

set total_load := 
 {'total_load'};

set other_loads := 
 {'other_load'};

set septic_bmp_totals := 
 {'total_parcels'};

param baseloads_N1 {comid_N1, seasons, years, loads_all} >= 0;
param riparianload_N1 {comid_N1, seasons, years, loads_riparian} >= 0;

param septic_bmp_implementationpotential {comid_all_N, septic_bmp} >= 0;
param septic_bmp_implementationtotal {comid_all_N, septic_bmp_totals} >= 0;

param area {comid_all, area_sub} >=0;
    
param urban_area {comid_all, urban_land_uses, urban_soil_groups, urban_area_sub} >=0;
param road_area {comid_all, road_soil_groups, road_area_sub} >=0;
param urban_bmp_implementationpotential {comid_all, urban_land_uses, urban_soil_groups, urban_bmp} >= 0;
param ag_bmp_implementationpotential {comid_all, ag_bmp} >= 0;
param unbuffered_banklength {comid_all, ripbuf_bmp} >= 0;
param total_banklength {comid_all} >= 0;

param ag_costs_capital {comid_all, ag_bmp};
param ag_costs_operations {comid_all, ag_bmp};
param graz_costs_capital {comid_all, graz_bmp};
param graz_costs_operations {comid_all, graz_bmp};
param point_costs_capital {comid_all, point_bmp};
param point_costs_operations {comid_all, point_bmp};
param urban_costs_capital {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param urban_costs_operations {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param road_costs_capital {comid_all, road_soil_groups, road_bmp};
param road_costs_operations {comid_all, road_soil_groups, road_bmp};
param ripbuf_costs_capital {comid_all, ripbuf_bmp};
param ripbuf_costs_operations {comid_all, ripbuf_bmp};

param septic_costs_capital {comid_all_N, septic_bmp} >= 0;
param septic_costs_operations {comid_all_N, septic_bmp} >= 0;



param ag_effic_N {comid_all_N, ag_bmp};
param graz_effic_N {comid_all_N, graz_bmp};
param point_effic_N {comid_all_N, point_bmp};
param urban_effic_N {comid_all_N, seasons, years, urban_land_uses, urban_soil_groups, urban_bmp};
param road_effic_N {comid_all_N, seasons, years, road_soil_groups, road_bmp};
param septic_effic_N {comid_all_N, septic_bmp};

param riparianremoval_N1 {c in comid_N1, s in seasons, y in years, b in ripbuf_bmp};
param loads_lim_N1 {seasons, years, limits} >= 0;


param transfer_coefficients_N1 {comid_N1, seasons, years, transfer_types};


param total_load_N1 {s in seasons, y in years, total_load} >= 0;


param agcost_frac >=0;
    
param agBMP_minarea;
param grazBMP_minarea;
param urbanBMP_minarea;
param roadBMP_minarea;

param urban_frac_min {urban_bmp} >=0, <= 1;
param urban_frac_max {u in urban_bmp} >= urban_frac_min[u], <= 1;
param road_frac_min {road_bmp} >=0, <= 1;
param road_frac_max {r in road_bmp} >= road_frac_min[r], <= 1;
param ag_frac_min {ag_bmp} >= 0, <= 1;
param ag_frac_max {a in ag_bmp} >= ag_frac_min[a], <= 1;
param graz_frac_min {graz_bmp} >= 0, <= 1;
param graz_frac_max {g in graz_bmp} >= graz_frac_min[g], <= 1;
param ripbuf_frac_min {ripbuf_bmp} >= 0, <= 1;
param ripbuf_frac_max {b in ripbuf_bmp} >= ripbuf_frac_min[b], <= 1;
  
param ps_coef {c in comid_all, p in point_bmp} := (point_costs_capital[c, p] + 
    point_costs_operations[c, p]);
param urban_coef {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} := urban_area[c,d,n,'urban'] * 
  (urban_costs_capital[c,d,n,u] + urban_costs_operations[c,d,n,u]) ;
param road_coef {c in comid_all, h in road_soil_groups, r in road_bmp} := road_area[c,h,'road'] * 
  (road_costs_capital[c,h,r] + road_costs_operations[c,h,r]) ;
param ag_coef {c in comid_all,  a in ag_bmp} := agcost_frac * area[c,'ag'] * 
  (ag_costs_capital[c,a] + ag_costs_operations[c,a]) ;

param graz_coef {c in comid_all, g in graz_bmp} := agcost_frac * area[c,'graz'] * 
  (graz_costs_capital[c,g] + graz_costs_operations[c,g]) ;
param ripbuf_coef {c in comid_all, b in ripbuf_bmp} := 
  agcost_frac * (ripbuf_costs_capital[c, b] + ripbuf_costs_operations[c, b]);
  
var agBMP_bin {comid_all, ag_bmp} binary;
var grazBMP_bin {comid_all, graz_bmp} binary;
var urbanBMP_bin {comid_all, urban_bmp} binary;
var roadBMP_bin {comid_all, road_bmp} binary;

var point_dec {c in comid_all, p in point_bmp} binary;
# correct unbounded fraction variables - AI solution created NEOS error  
var urban_frac {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}
  >= 0, <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u];
#  := 0; # default is 0 so not needed; 
#    >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u],  
#    <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u],
#    :=0;
var ag_frac {c in comid_all, a in ag_bmp}
   >= 0,
   <= ag_frac_max[a] * ag_bmp_implementationpotential[c,a];
#   := 0
#    >= ag_frac_min[a] * ag_bmp_implementationpotential[c, a],  
#    <= ag_frac_max[a] * ag_bmp_implementationpotential[c, a],
#    :=0;
var road_frac {c in comid_all, h in road_soil_groups, r in road_bmp}
  >= 0, 
  <= road_frac_max[r];
#  := 0;  
#   >= road_frac_min[r],
#   <= road_frac_max[r],
#   :=0;
var graz_frac {c in comid_all, g in graz_bmp}
  >= 0,
  <= graz_frac_max[g];
#  := 0;
#   >= graz_frac_min[g],
#   <= graz_frac_max[g],
#   :=0;
var ripbuf_length {c in comid_all, b in ripbuf_bmp} 
   >= 0, 
   <= unbuffered_banklength[c, b] * ripbuf_frac_max[b];
#   := 0;
   

var inc_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;
var no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_ag_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_graz_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_urb_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_road_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_point_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_septic_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

minimize cost: sum {c in comid_all, p in point_bmp} (ps_coef[c,p] * point_dec[c,p]) +
sum {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} (urban_coef[c,d,n,u] * urban_frac[c,d,n,u]) +
sum {c in comid_all, h in road_soil_groups, r in road_bmp} (road_coef[c,h,r] * road_frac[c,h,r]) +
sum {c in comid_all, a in ag_bmp} (ag_coef[c,a] * ag_frac[c,a]) +
sum {c in comid_all, g in graz_bmp} (graz_coef[c,g] * graz_frac[c,g]) +
 

sum {c in comid_all, b in ripbuf_bmp} (ripbuf_coef[c, b] * ripbuf_length[c, b]);
subject to calc_red_ag_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_ag_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'ag'] * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a]));

  
    subject to calc_red_graz_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_graz_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'graz'] * (1 - sum {g in graz_bmp}(graz_effic_N[c,g] * graz_frac[c,g]));

  
    subject to calc_red_urb_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_urb_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'urban'] * (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}(urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]));

  
    subject to calc_red_road_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_road_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'road'] * (1 - sum{h in road_soil_groups, r in road_bmp}(road_effic_N[c,s,y,h,r] * road_frac[c,h,r]));
 
    
    subject to calc_red_point_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_point_load_N1[c,s,y] = 
 
        (baseloads_N1[c,s,y,'point'] + 0)  * (1 - sum{p in point_bmp}(point_effic_N[c,p] * point_dec[c,p]));

          
    subject to calc_red_septic_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_septic_load_N1[c,s,y] =
0;

          
    subject to calc_riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years}:
          riparian_reduction_load_N1[c,s,y] =  
          sum {b in ripbuf_bmp}

        ripbuf_length[c,b] * riparianremoval_N1[c,s,y,b];
          #*

          # (
          #   reduced_ag_load_N1[c,s,y] / riparianload_N1[c,s,y,'riparian']

          #   +

          #     (1 - sum {d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}

          #      urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u])

          #   * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag'])

          #   / riparianload_N1[c,s,y,'riparian']

          # );

  
      subject to calc_no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years}:

          no_storage_NPSload_N1[c,s,y] =
          baseloads_N1[c,s,y,'other'] +
          reduced_ag_load_N1[c,s,y] + 
          reduced_urb_load_N1[c,s,y] +   
          reduced_road_load_N1[c,s,y] +
          reduced_point_load_N1[c,s,y] +
          reduced_septic_load_N1[c,s,y] -
          riparian_reduction_load_N1[c,s,y];
 
          
      subject to calc_red_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_storage_load_N1[c,s,y] =

        if transfer_coefficients_N1[c,s,y,'notrib'] = 1 then
 
          (no_storage_NPSload_N1[c,s,y] * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s = first(seasons) then

          if y = first(years) then
            baseloads_N1[c,s,y,'storage']

          else if y != first(years) then

            (no_storage_NPSload_N1[c,4,y-1] 
            * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s != first(seasons) then

          (no_storage_NPSload_N1[c,s-1,y] 
* transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff']);

    
    subject to calc_inc_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      inc_storage_load_N1[c,s,y] =

        reduced_storage_load_N1[c,s,y] + 
        reduced_ag_load_N1[c,s,y] + 
        reduced_urb_load_N1[c,s,y] +   
        reduced_road_load_N1[c,s,y] +
        reduced_point_load_N1[c,s,y] +
        reduced_septic_load_N1[c,s,y] -
        riparian_reduction_load_N1[c,s,y];

    
subject to total_loads_N1{s in seasons, y in years: y = 7}:
sum{c in comid_N1} (inc_storage_load_N1[c,s,y]) <= loads_lim_N1[s,7,'limits'];

subject to riparian_loads_N1 {c in comid_N1, s in seasons, y in years}:
sum {b in ripbuf_bmp} ripbuf_length[c, b] * riparianremoval_N1[c,s,y,b] <= 
 
            (baseloads_N1[c,s,y,'ag'] 
 
            * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a])) 

            + (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} 

              (urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]))
 
            * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag']));

subject to urban_frac_min2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u] * urbanBMP_bin[c,u];
    subject to ag_frac_min2 {c in comid_all, a in ag_bmp}:
ag_frac[c,a] >= ag_frac_min[a] * ag_bmp_implementationpotential[c,a] * agBMP_bin[c,a];
    subject to graz_frac_min2{c in comid_all,g in graz_bmp}:
graz_frac[c,g] >= graz_frac_min[g] * grazBMP_bin[c,g];

#    subject to road_frac_min2{c in comid_all, h in road_soil_groups,r in road_bmp}:
# road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND replacement
  subject to road_frac_min2 {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND added Aggregate min area per BMP (recommended) 
  subject to road_treat_min {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] * road_area[c,h,'road'] >= roadBMP_minarea * roadBMP_bin[c,r];
    
subject to ag_treat_min {c in comid_all, a in ag_bmp}:
ag_frac[c,a] * area[c,'ag'] >= agBMP_minarea * agBMP_bin[c,a];

subject to graz_treat_min {c in comid_all, g in graz_bmp}:
graz_frac[c,g] * area[c,'graz'] >= grazBMP_minarea * grazBMP_bin[c,g];

subject to urban_treat_min {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] * urban_area[c,d,n,'urban'] >= urbanBMP_minarea * urbanBMP_bin[c,u];
  
subject to ag_frac_const {c in comid_all, a in ag_bmp}:
ag_frac[c,a] <= agBMP_bin[c,a];

subject to graz_frac_const {c in comid_all, g in graz_bmp}:
graz_frac[c,g] <= grazBMP_bin[c,g];
  
subject to urban_frac_const {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] <= urbanBMP_bin[c,u];

#ND added missing 6/3/26;
subject to road_frac_const {c in comid_all, h in road_soil_groups, r in road_bmp}:
    road_frac[c,h,r] <= roadBMP_bin[c,r];

subject to ag_frac_limit {c in comid_all}: 
sum {a in ag_bmp} ag_frac[c,a] <= 1;
# prevents multiple BMPs being implemented on the same area

subject to graz_frac_limit {c in comid_all}: 
sum {g in graz_bmp} graz_frac[c,g] <= 1;
# prevents multiple BMPs being implemented on the same area

#subject to urban_frac_limit {c in comid_all}: 
#sum {u in urban_bmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,u] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - drop
# Per-subarea (d,n) constraint
 subject to urban_frac_limit2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups}:
  sum {u in urban_bmp} urban_frac[c,d,n,u] <= 1;

subject to road_frac_limit {c in comid_all}: 
sum {r in road_bmp, h in road_soil_groups} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - try dropping this because not updated during bootstraps
# Per-soil-group constraint
# subject to road_frac_limit2 {c in comid_all, h in road_soil_groups}:
#  sum {r in road_bmp} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same sub-area

subject to point_dec_limit {c in comid_all}: 
sum {p in point_bmp} point_dec[c,p] <= 1;
# limits each WWTP to one upgrade

subject to total_banks {c in comid_all}:
sum {b in ripbuf_bmp} ripbuf_length[c,b] <=  
   unbuffered_banklength[c,'Forested_Buffer']; #ND 7/8/2026 changed from max
  


subject to roads_and_parkinglots {c in comid_all}:
sum{up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,up] <= max {up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} 
   urban_bmp_implementationpotential[c,d,n,up];


subject to tiledrains {c in comid_all}:
sum{agti in ag_tilebmp} ag_frac[c, agti] <= max {agti in ag_tilebmp}
   ag_bmp_implementationpotential[c,agti];

