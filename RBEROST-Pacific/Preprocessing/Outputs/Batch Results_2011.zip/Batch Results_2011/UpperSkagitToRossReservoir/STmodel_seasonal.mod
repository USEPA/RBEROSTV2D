#STmodel_seasonal.mod
      
set comid_all :=
{'24254869','24254871','24254873','24254875','24254877','24254879','24254881','24254883','24254885','24254889','24254891','24254893','24254895','24254897','24254899','24254901','24254903','24254905','24254907','24254909','24254911','24254913','24254915','24254919','24254921','24254923','24254925','24254931','24254933','24254935','24254937','24254939','24254941','24254943','24254945','24254947','24254949','24254951','24254953','24254955','24254957','24254959','24254961','24254963','24254965','24254967','24254969','24254971','24254973','24254975','24254977','24254979','24254981','24254983','24254985','24254987','24254989','24254991','24254993','24254995','24254997','24254999','24255001','24255003','24255005','24255007','24255009','24255011','24255013','24255015','24255017','24255019','24255021','24255023','24255025','24255027','24255029','24255031','24255033','24255035','24255037','24255039','24255041','24255043','24255045','24255047','24255049','24255051','24255053','24255055','24255057','24255059','24255061','24255063','24255065','24255067','24255069','24255071','24255073','24255075','24255077','24255079','24255081','24255083','24255085','24255087','24255089','24255091','24255093','24255095','24255097','24255099','24255101','24255103','24255105','24255107','24255109','24255111','24255113','24255115','24255117','24255119','24255121','24255123','24255125','24255127','24255129','24255131','24255133','24255137','24255139','24255141','24255143','24255145','24255147','24255149','24255151','24255153','24255155','24255157','24255159','24255161','24255163','24255165','24255169','24255171','24255173','24255175','24255177','24255179','24255181','24255183','24255185','24255187','24255189','24255191','24255193','24255195','24255197','24255199','24255201','24255203','24255205','24255207','24255209','24255211','24255213','24255215','24255217','24255219','24255221','24255223','24255225','24255227','24255229','24255231','24255233','24255235','24255237','24255239','24255241','24255243','24255245','24255247','24255249','24255251','24255253','24255255','24255257','24255259','24255261','24255263','24255265','24255267','24255269','24255271','24255273','24255275','24255277','24255279','24255281','24255283','24255285','24255287','24255737','24255739','24255741','24255743','24255745','24255747','24255749','24255751','24255753','24255761','24255763','24255765','24255767','24255769','24255771','24255773','24255775','24255777','24255779','24255781','24255783','24255785','24255787','24255789','24255791','24255793','24255795','24255797','24255799','24255801','24255803','24255805','24255807','24255809','24255811','24255813','24255815','24255817','24255819','24255821','24255823','24255825','24255827','24255829','24255831','24255833','24255835','24255837','24255839','24255841','24255845','24255847','24255849','24255851','24255853','24255855','24255857','24256069','24256071','24256101','24256103','24256105','24256107','24256109','24256111','24256135','24256137','24256139','24256141','24256143','24256145','24256147','24256155','24256157','24256159','24256161','24256163','24256175','24256177','24256197','24256199','24256201','24256213','24256215','24256217','24256243','24256247','24256249','24256553','24256583','24256599','24256605','24256627','24256637','24256639','24256661','24256671','24256683','24256685','24256691','24256695','24256703','24256711','24256713','24256715','24256719','24256727','24256743','24256757','24256763','24256777','24256781','24256787','24256789','24256793','24256797','24256799','24256803','24256805','24256811','24256829','24256833','24256839','24256843','24256845','24256855','24256857','24256865','24256869','24256879','24256889','24256893','24256895','24256897','24256899','24256907','24256909','24256931','24256935','24256937','24256945','24256951','24256953','24256955','24256961','24256969','24256973','24256975','24256979','24256983','24256985','24256989','24256999','24257005','24257017','24257021','24257025','24257037','24257039','24257041','24257043','24257045','24257047','24257051','24257053','24257067','24257069','24257073','24257077','24257079','24257087','24257089','24257101','24257109','24257117','24257119','24257123','24257127','24257129','24257135','24257137','24257139','24257141','24257155','24257159','24257161','24257165','24257167','24257173','24257177','24257179','24257181','24257183','24257185','24257189','24257191','24257193','24257197','24257199','24257201','24257203','24257205','24257207','24257209','24257211','24257213','24257215','24257217','24257219','24257221','24257223','24257227','24257229','24257231','24257239','24257241','24257243','24257249','24257251','24257255','24257257','24257259','24257263','24257265','24257267','24257269','24257271','24257283','24257285','24257287','24257289','24257293','24257297','24257303','24257305','24257307','24257311','24257313','24257315','24257317','24257319','24257321','24257323','24257325','24257327','24257329','24257331','24257333','24257335','24257337','24257339','24257341','24257343','24257345','24257347','24257349','24257351','24257355','24257357','24257359','24257361','24257363','24257365','24257367','24257369','24257371','24257373','24257375','24257377','24257379','24257381','24257383','24257385','24257387','24257389','24257391','24257393','24257395','24257397','24257399','24257401','24257403','24257405','24257407','24257409','24257411','24257413','24257415','24257417','24257419','24257421','24257423','24257425','24257427','24257429','24257431','24257433','24257435','24257437','24257439','24257441','24257443','24257445','24257447','24257449','24257451','24257453','24257455','24257457','24257459','24257461','24257463','24257465','24257467','24257499','24257529','24257531','24257535','24257537','24257539','24257541','24257543','24257545','24257547','24257549','24257551','24257553','24257555','24257557','24257559','24257561','24257563','24257565','24257567','24257569','24257571','24257573','24257575','24257577','24257579','24257581','24257583','24257585','24257587','24257593','24257595','24257597','24257599','24257603','24257605','24257607','24257609','24257611','24257615','24257617','24257623','24257625','24257639','24257647','24257649','24257659','24257689','24257693','24257719','24257723','25184466','25184468','25184470','25184480','25184482','947110151','947110190','947110191'};

set comid_all_N within comid_all := {'24254869','24254871','24254873','24254875','24254877','24254879','24254881','24254883','24254885','24254889','24254891','24254893','24254895','24254897','24254899','24254901','24254903','24254905','24254907','24254909','24254911','24254913','24254915','24254919','24254921','24254923','24254925','24254931','24254933','24254935','24254937','24254939','24254941','24254943','24254945','24254947','24254949','24254951','24254953','24254955','24254957','24254959','24254961','24254963','24254965','24254967','24254969','24254971','24254973','24254975','24254977','24254979','24254981','24254983','24254985','24254987','24254989','24254991','24254993','24254995','24254997','24254999','24255001','24255003','24255005','24255007','24255009','24255011','24255013','24255015','24255017','24255019','24255021','24255023','24255025','24255027','24255029','24255031','24255033','24255035','24255037','24255039','24255041','24255043','24255045','24255047','24255049','24255051','24255053','24255055','24255057','24255059','24255061','24255063','24255065','24255067','24255069','24255071','24255073','24255075','24255077','24255079','24255081','24255083','24255085','24255087','24255089','24255091','24255093','24255095','24255097','24255099','24255101','24255103','24255105','24255107','24255109','24255111','24255113','24255115','24255117','24255119','24255121','24255123','24255125','24255127','24255129','24255131','24255133','24255137','24255139','24255141','24255143','24255145','24255147','24255149','24255151','24255153','24255155','24255157','24255159','24255161','24255163','24255165','24255169','24255171','24255173','24255175','24255177','24255179','24255181','24255183','24255185','24255187','24255189','24255191','24255193','24255195','24255197','24255199','24255201','24255203','24255205','24255207','24255209','24255211','24255213','24255215','24255217','24255219','24255221','24255223','24255225','24255227','24255229','24255231','24255233','24255235','24255237','24255239','24255241','24255243','24255245','24255247','24255249','24255251','24255253','24255255','24255257','24255259','24255261','24255263','24255265','24255267','24255269','24255271','24255273','24255275','24255277','24255279','24255281','24255283','24255285','24255287','24255737','24255739','24255741','24255743','24255745','24255747','24255749','24255751','24255753','24255761','24255763','24255765','24255767','24255769','24255771','24255773','24255775','24255777','24255779','24255781','24255783','24255785','24255787','24255789','24255791','24255793','24255795','24255797','24255799','24255801','24255803','24255805','24255807','24255809','24255811','24255813','24255815','24255817','24255819','24255821','24255823','24255825','24255827','24255829','24255831','24255833','24255835','24255837','24255839','24255841','24255845','24255847','24255849','24255851','24255853','24255855','24255857','24256069','24256071','24256101','24256103','24256105','24256107','24256109','24256111','24256135','24256137','24256139','24256141','24256143','24256145','24256147','24256155','24256157','24256159','24256161','24256163','24256175','24256177','24256197','24256199','24256201','24256213','24256215','24256217','24256243','24256247','24256249','24256553','24256583','24256599','24256605','24256627','24256637','24256639','24256661','24256671','24256683','24256685','24256691','24256695','24256703','24256711','24256713','24256715','24256719','24256727','24256743','24256757','24256763','24256777','24256781','24256787','24256789','24256793','24256797','24256799','24256803','24256805','24256811','24256829','24256833','24256839','24256843','24256845','24256855','24256857','24256865','24256869','24256879','24256889','24256893','24256895','24256897','24256899','24256907','24256909','24256931','24256935','24256937','24256945','24256951','24256953','24256955','24256961','24256969','24256973','24256975','24256979','24256983','24256985','24256989','24256999','24257005','24257017','24257021','24257025','24257037','24257039','24257041','24257043','24257045','24257047','24257051','24257053','24257067','24257069','24257073','24257077','24257079','24257087','24257089','24257101','24257109','24257117','24257119','24257123','24257127','24257129','24257135','24257137','24257139','24257141','24257155','24257159','24257161','24257165','24257167','24257173','24257177','24257179','24257181','24257183','24257185','24257189','24257191','24257193','24257197','24257199','24257201','24257203','24257205','24257207','24257209','24257211','24257213','24257215','24257217','24257219','24257221','24257223','24257227','24257229','24257231','24257239','24257241','24257243','24257249','24257251','24257255','24257257','24257259','24257263','24257265','24257267','24257269','24257271','24257283','24257285','24257287','24257289','24257293','24257297','24257303','24257305','24257307','24257311','24257313','24257315','24257317','24257319','24257321','24257323','24257325','24257327','24257329','24257331','24257333','24257335','24257337','24257339','24257341','24257343','24257345','24257347','24257349','24257351','24257355','24257357','24257359','24257361','24257363','24257365','24257367','24257369','24257371','24257373','24257375','24257377','24257379','24257381','24257383','24257385','24257387','24257389','24257391','24257393','24257395','24257397','24257399','24257401','24257403','24257405','24257407','24257409','24257411','24257413','24257415','24257417','24257419','24257421','24257423','24257425','24257427','24257429','24257431','24257433','24257435','24257437','24257439','24257441','24257443','24257445','24257447','24257449','24257451','24257453','24257455','24257457','24257459','24257461','24257463','24257465','24257467','24257499','24257529','24257531','24257535','24257537','24257539','24257541','24257543','24257545','24257547','24257549','24257551','24257553','24257555','24257557','24257559','24257561','24257563','24257565','24257567','24257569','24257571','24257573','24257575','24257577','24257579','24257581','24257583','24257585','24257587','24257593','24257595','24257597','24257599','24257603','24257605','24257607','24257609','24257611','24257615','24257617','24257623','24257625','24257639','24257647','24257649','24257659','24257689','24257693','24257719','24257723','25184466','25184468','25184470','25184480','25184482','947110151','947110190','947110191'};

set comid_all_P within comid_all := {};

set comid_N1 within comid_all_N := {'24254869','24254871','24254873','24254875','24254877','24254879','24254881','24254883','24254885','24254889','24254891','24254893','24254895','24254897','24254899','24254901','24254903','24254905','24254907','24254909','24254911','24254913','24254915','24254919','24254921','24254923','24254925','24254931','24254933','24254935','24254937','24254939','24254941','24254943','24254945','24254947','24254949','24254951','24254953','24254955','24254957','24254959','24254961','24254963','24254965','24254967','24254969','24254971','24254973','24254975','24254977','24254979','24254981','24254983','24254985','24254987','24254989','24254991','24254993','24254995','24254997','24254999','24255001','24255003','24255005','24255007','24255009','24255011','24255013','24255015','24255017','24255019','24255021','24255023','24255025','24255027','24255029','24255031','24255033','24255035','24255037','24255039','24255041','24255043','24255045','24255047','24255049','24255051','24255053','24255055','24255057','24255059','24255061','24255063','24255065','24255067','24255069','24255071','24255073','24255075','24255077','24255079','24255081','24255083','24255085','24255087','24255089','24255091','24255093','24255095','24255097','24255099','24255101','24255103','24255105','24255107','24255109','24255111','24255113','24255115','24255117','24255119','24255121','24255123','24255125','24255127','24255129','24255131','24255133','24255137','24255139','24255141','24255143','24255145','24255147','24255149','24255151','24255153','24255155','24255157','24255159','24255161','24255163','24255165','24255169','24255171','24255173','24255175','24255177','24255179','24255181','24255183','24255185','24255187','24255189','24255191','24255193','24255195','24255197','24255199','24255201','24255203','24255205','24255207','24255209','24255211','24255213','24255215','24255217','24255219','24255221','24255223','24255225','24255227','24255229','24255231','24255233','24255235','24255237','24255239','24255241','24255243','24255245','24255247','24255249','24255251','24255253','24255255','24255257','24255259','24255261','24255263','24255265','24255267','24255269','24255271','24255273','24255275','24255277','24255279','24255281','24255283','24255285','24255287','24255737','24255739','24255741','24255743','24255745','24255747','24255749','24255751','24255753','24255761','24255763','24255765','24255767','24255769','24255771','24255773','24255775','24255777','24255779','24255781','24255783','24255785','24255787','24255789','24255791','24255793','24255795','24255797','24255799','24255801','24255803','24255805','24255807','24255809','24255811','24255813','24255815','24255817','24255819','24255821','24255823','24255825','24255827','24255829','24255831','24255833','24255835','24255837','24255839','24255841','24255845','24255847','24255849','24255851','24255853','24255855','24255857','24256069','24256071','24256101','24256103','24256105','24256107','24256109','24256111','24256135','24256137','24256139','24256141','24256143','24256145','24256147','24256155','24256157','24256159','24256161','24256163','24256175','24256177','24256197','24256199','24256201','24256213','24256215','24256217','24256243','24256247','24256249','24256553','24256583','24256599','24256605','24256627','24256637','24256639','24256661','24256671','24256683','24256685','24256691','24256695','24256703','24256711','24256713','24256715','24256719','24256727','24256743','24256757','24256763','24256777','24256781','24256787','24256789','24256793','24256797','24256799','24256803','24256805','24256811','24256829','24256833','24256839','24256843','24256845','24256855','24256857','24256865','24256869','24256879','24256889','24256893','24256895','24256897','24256899','24256907','24256909','24256931','24256935','24256937','24256945','24256951','24256953','24256955','24256961','24256969','24256973','24256975','24256979','24256983','24256985','24256989','24256999','24257005','24257017','24257021','24257025','24257037','24257039','24257041','24257043','24257045','24257047','24257051','24257053','24257067','24257069','24257073','24257077','24257079','24257087','24257089','24257101','24257109','24257117','24257119','24257123','24257127','24257129','24257135','24257137','24257139','24257141','24257155','24257159','24257161','24257165','24257167','24257173','24257177','24257179','24257181','24257183','24257185','24257189','24257191','24257193','24257197','24257199','24257201','24257203','24257205','24257207','24257209','24257211','24257213','24257215','24257217','24257219','24257221','24257223','24257227','24257229','24257231','24257239','24257241','24257243','24257249','24257251','24257255','24257257','24257259','24257263','24257265','24257267','24257269','24257271','24257283','24257285','24257287','24257289','24257293','24257297','24257303','24257305','24257307','24257311','24257313','24257315','24257317','24257319','24257321','24257323','24257325','24257327','24257329','24257331','24257333','24257335','24257337','24257339','24257341','24257343','24257345','24257347','24257349','24257351','24257355','24257357','24257359','24257361','24257363','24257365','24257367','24257369','24257371','24257373','24257375','24257377','24257379','24257381','24257383','24257385','24257387','24257389','24257391','24257393','24257395','24257397','24257399','24257401','24257403','24257405','24257407','24257409','24257411','24257413','24257415','24257417','24257419','24257421','24257423','24257425','24257427','24257429','24257431','24257433','24257435','24257437','24257439','24257441','24257443','24257445','24257447','24257449','24257451','24257453','24257455','24257457','24257459','24257461','24257463','24257465','24257467','24257499','24257529','24257531','24257535','24257537','24257539','24257541','24257543','24257545','24257547','24257549','24257551','24257553','24257555','24257557','24257559','24257561','24257563','24257565','24257567','24257569','24257571','24257573','24257575','24257577','24257579','24257581','24257583','24257585','24257587','24257593','24257595','24257597','24257599','24257603','24257605','24257607','24257609','24257611','24257615','24257617','24257623','24257625','24257639','24257647','24257649','24257659','24257689','24257693','24257719','24257723','25184466','25184468','25184470','25184480','25184482','947110151','947110190','947110191'};

set comid_P1 within comid_all_P := {};

set seasons := 1..4 ordered; 

set years := 6..7 ordered;

set urban_land_uses := {'UIDU','URHD','URLD','URMD'};

set urban_soil_groups := {'A','B','C','D'};

set road_soil_groups := {'A','B','C','D'};


set urban_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Green_Roof','Infiltration_Basin','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set urban_pervbmp within urban_bmp :=
{'Porous_Pavement_w_UD'};

set road_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Infiltration_Basin','Infiltration_Chamber','Infiltration_Trench','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set ag_bmp :=
{'Conservation','Contour_Farming','Fert_75','Fert_90','Filterstrip','MIN_TILL','Terrace_Waterway','Terrace_Only','Waterway_Only','Grade_Stabilization','Diversion','Cover_Crops','Drainage_Management','Manure_Injection'};

set ag_tilebmp within ag_bmp :=
{'Drainage_Management'};

set septic_bmp :=
{'none'};

set graz_bmp :=
{'Offsite_Water'};

set ripbuf_bmp :=
{'Grassed_Buffer','Forested_Buffer'};

set point_bmp :=
{'C','C_F','FOURBDP_M','FOURBDP_M_C_F','MLE','MLE_C','C_M','M','SBR','SBR_C','SBR_C_F','SBR_DNF_C_F_M','SBR_DNF_M','FOURBDP_MBR_M','FOURBDP_MBR_M_C','MLE_MBR','MLE_MBR_C'};

set loads_all :=
{'point', 'urban', 'road', 'ag', 'septic', 'graz', 'storage', 'other'};
  
set area_sub :=
{'ag', 'graz'};
set urban_area_sub :=
{'urban'};
set road_area_sub :=
{'road'};

set transfer_types := {'coeff', 'notrib'};

set loads_riparian := 
 {'riparian'};

set limits := 
 {'limits'};

set total_load := 
 {'total_load'};

set other_loads := 
 {'other_load'};

set septic_bmp_totals := 
 {'total_parcels'};

param baseloads_N1 {comid_N1, seasons, years, loads_all} >= 0;
param riparianload_N1 {comid_N1, seasons, years, loads_riparian} >= 0;

param septic_bmp_implementationpotential {comid_all_N, septic_bmp} >= 0;
param septic_bmp_implementationtotal {comid_all_N, septic_bmp_totals} >= 0;

param area {comid_all, area_sub} >=0;
    
param urban_area {comid_all, urban_land_uses, urban_soil_groups, urban_area_sub} >=0;
param road_area {comid_all, road_soil_groups, road_area_sub} >=0;
param urban_bmp_implementationpotential {comid_all, urban_land_uses, urban_soil_groups, urban_bmp} >= 0;
param ag_bmp_implementationpotential {comid_all, ag_bmp} >= 0;
param unbuffered_banklength {comid_all, ripbuf_bmp} >= 0;
param total_banklength {comid_all} >= 0;

param ag_costs_capital {comid_all, ag_bmp};
param ag_costs_operations {comid_all, ag_bmp};
param graz_costs_capital {comid_all, graz_bmp};
param graz_costs_operations {comid_all, graz_bmp};
param point_costs_capital {comid_all, point_bmp};
param point_costs_operations {comid_all, point_bmp};
param urban_costs_capital {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param urban_costs_operations {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param road_costs_capital {comid_all, road_soil_groups, road_bmp};
param road_costs_operations {comid_all, road_soil_groups, road_bmp};
param ripbuf_costs_capital {comid_all, ripbuf_bmp};
param ripbuf_costs_operations {comid_all, ripbuf_bmp};

param septic_costs_capital {comid_all_N, septic_bmp} >= 0;
param septic_costs_operations {comid_all_N, septic_bmp} >= 0;



param ag_effic_N {comid_all_N, ag_bmp};
param graz_effic_N {comid_all_N, graz_bmp};
param point_effic_N {comid_all_N, point_bmp};
param urban_effic_N {comid_all_N, seasons, years, urban_land_uses, urban_soil_groups, urban_bmp};
param road_effic_N {comid_all_N, seasons, years, road_soil_groups, road_bmp};
param septic_effic_N {comid_all_N, septic_bmp};

param riparianremoval_N1 {c in comid_N1, s in seasons, y in years, b in ripbuf_bmp};
param loads_lim_N1 {seasons, years, limits} >= 0;


param transfer_coefficients_N1 {comid_N1, seasons, years, transfer_types};


param total_load_N1 {s in seasons, y in years, total_load} >= 0;


param agcost_frac >=0;
    
param agBMP_minarea;
param grazBMP_minarea;
param urbanBMP_minarea;
param roadBMP_minarea;

param urban_frac_min {urban_bmp} >=0, <= 1;
param urban_frac_max {u in urban_bmp} >= urban_frac_min[u], <= 1;
param road_frac_min {road_bmp} >=0, <= 1;
param road_frac_max {r in road_bmp} >= road_frac_min[r], <= 1;
param ag_frac_min {ag_bmp} >= 0, <= 1;
param ag_frac_max {a in ag_bmp} >= ag_frac_min[a], <= 1;
param graz_frac_min {graz_bmp} >= 0, <= 1;
param graz_frac_max {g in graz_bmp} >= graz_frac_min[g], <= 1;
param ripbuf_frac_min {ripbuf_bmp} >= 0, <= 1;
param ripbuf_frac_max {b in ripbuf_bmp} >= ripbuf_frac_min[b], <= 1;
  
param ps_coef {c in comid_all, p in point_bmp} := (point_costs_capital[c, p] + 
    point_costs_operations[c, p]);
param urban_coef {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} := urban_area[c,d,n,'urban'] * 
  (urban_costs_capital[c,d,n,u] + urban_costs_operations[c,d,n,u]) ;
param road_coef {c in comid_all, h in road_soil_groups, r in road_bmp} := road_area[c,h,'road'] * 
  (road_costs_capital[c,h,r] + road_costs_operations[c,h,r]) ;
param ag_coef {c in comid_all,  a in ag_bmp} := agcost_frac * area[c,'ag'] * 
  (ag_costs_capital[c,a] + ag_costs_operations[c,a]) ;

param graz_coef {c in comid_all, g in graz_bmp} := agcost_frac * area[c,'graz'] * 
  (graz_costs_capital[c,g] + graz_costs_operations[c,g]) ;
param ripbuf_coef {c in comid_all, b in ripbuf_bmp} := 
  agcost_frac * (ripbuf_costs_capital[c, b] + ripbuf_costs_operations[c, b]);
  
var agBMP_bin {comid_all, ag_bmp} binary;
var grazBMP_bin {comid_all, graz_bmp} binary;
var urbanBMP_bin {comid_all, urban_bmp} binary;
var roadBMP_bin {comid_all, road_bmp} binary;

var point_dec {c in comid_all, p in point_bmp} binary;
# correct unbounded fraction variables - AI solution created NEOS error  
var urban_frac {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}
  >= 0, <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u];
#  := 0; # default is 0 so not needed; 
#    >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u],  
#    <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u],
#    :=0;
var ag_frac {c in comid_all, a in ag_bmp}
   >= 0,
   <= ag_frac_max[a] * ag_bmp_implementationpotential[c,a];
#   := 0
#    >= ag_frac_min[a] * ag_bmp_implementationpotential[c, a],  
#    <= ag_frac_max[a] * ag_bmp_implementationpotential[c, a],
#    :=0;
var road_frac {c in comid_all, h in road_soil_groups, r in road_bmp}
  >= 0, 
  <= road_frac_max[r];
#  := 0;  
#   >= road_frac_min[r],
#   <= road_frac_max[r],
#   :=0;
var graz_frac {c in comid_all, g in graz_bmp}
  >= 0,
  <= graz_frac_max[g];
#  := 0;
#   >= graz_frac_min[g],
#   <= graz_frac_max[g],
#   :=0;
var ripbuf_length {c in comid_all, b in ripbuf_bmp} 
   >= 0, 
   <= unbuffered_banklength[c, b] * ripbuf_frac_max[b];
#   := 0;
   

var inc_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;
var no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_ag_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_graz_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_urb_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_road_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_point_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_septic_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

minimize cost: sum {c in comid_all, p in point_bmp} (ps_coef[c,p] * point_dec[c,p]) +
sum {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} (urban_coef[c,d,n,u] * urban_frac[c,d,n,u]) +
sum {c in comid_all, h in road_soil_groups, r in road_bmp} (road_coef[c,h,r] * road_frac[c,h,r]) +
sum {c in comid_all, a in ag_bmp} (ag_coef[c,a] * ag_frac[c,a]) +
sum {c in comid_all, g in graz_bmp} (graz_coef[c,g] * graz_frac[c,g]) +
 

sum {c in comid_all, b in ripbuf_bmp} (ripbuf_coef[c, b] * ripbuf_length[c, b]);
subject to calc_red_ag_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_ag_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'ag'] * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a]));

  
    subject to calc_red_graz_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_graz_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'graz'] * (1 - sum {g in graz_bmp}(graz_effic_N[c,g] * graz_frac[c,g]));

  
    subject to calc_red_urb_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_urb_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'urban'] * (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}(urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]));

  
    subject to calc_red_road_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_road_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'road'] * (1 - sum{h in road_soil_groups, r in road_bmp}(road_effic_N[c,s,y,h,r] * road_frac[c,h,r]));
 
    
    subject to calc_red_point_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_point_load_N1[c,s,y] = 
 
        (baseloads_N1[c,s,y,'point'] + 0)  * (1 - sum{p in point_bmp}(point_effic_N[c,p] * point_dec[c,p]));

          
    subject to calc_red_septic_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_septic_load_N1[c,s,y] =
0;

          
    subject to calc_riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years}:
          riparian_reduction_load_N1[c,s,y] =  
          sum {b in ripbuf_bmp}

        ripbuf_length[c,b] * riparianremoval_N1[c,s,y,b];
          #*

          # (
          #   reduced_ag_load_N1[c,s,y] / riparianload_N1[c,s,y,'riparian']

          #   +

          #     (1 - sum {d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}

          #      urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u])

          #   * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag'])

          #   / riparianload_N1[c,s,y,'riparian']

          # );

  
      subject to calc_no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years}:

          no_storage_NPSload_N1[c,s,y] =
          baseloads_N1[c,s,y,'other'] +
          reduced_ag_load_N1[c,s,y] + 
          reduced_urb_load_N1[c,s,y] +   
          reduced_road_load_N1[c,s,y] +
          reduced_point_load_N1[c,s,y] +
          reduced_septic_load_N1[c,s,y] -
          riparian_reduction_load_N1[c,s,y];
 
          
      subject to calc_red_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_storage_load_N1[c,s,y] =

        if transfer_coefficients_N1[c,s,y,'notrib'] = 1 then
 
          (no_storage_NPSload_N1[c,s,y] * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s = first(seasons) then

          if y = first(years) then
            baseloads_N1[c,s,y,'storage']

          else if y != first(years) then

            (no_storage_NPSload_N1[c,4,y-1] 
            * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s != first(seasons) then

          (no_storage_NPSload_N1[c,s-1,y] 
* transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff']);

    
    subject to calc_inc_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      inc_storage_load_N1[c,s,y] =

        reduced_storage_load_N1[c,s,y] + 
        reduced_ag_load_N1[c,s,y] + 
        reduced_urb_load_N1[c,s,y] +   
        reduced_road_load_N1[c,s,y] +
        reduced_point_load_N1[c,s,y] +
        reduced_septic_load_N1[c,s,y] -
        riparian_reduction_load_N1[c,s,y];

    
subject to total_loads_N1{s in seasons, y in years: y = 7}:
sum{c in comid_N1} (inc_storage_load_N1[c,s,y]) <= loads_lim_N1[s,7,'limits'];

subject to riparian_loads_N1 {c in comid_N1, s in seasons, y in years}:
sum {b in ripbuf_bmp} ripbuf_length[c, b] * riparianremoval_N1[c,s,y,b] <= 
 
            (baseloads_N1[c,s,y,'ag'] 
 
            * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a])) 

            + (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} 

              (urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]))
 
            * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag']));

subject to urban_frac_min2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u] * urbanBMP_bin[c,u];
    subject to ag_frac_min2 {c in comid_all, a in ag_bmp}:
ag_frac[c,a] >= ag_frac_min[a] * ag_bmp_implementationpotential[c,a] * agBMP_bin[c,a];
    subject to graz_frac_min2{c in comid_all,g in graz_bmp}:
graz_frac[c,g] >= graz_frac_min[g] * grazBMP_bin[c,g];

#    subject to road_frac_min2{c in comid_all, h in road_soil_groups,r in road_bmp}:
# road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND replacement
  subject to road_frac_min2 {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND added Aggregate min area per BMP (recommended) 
  subject to road_treat_min {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] * road_area[c,h,'road'] >= roadBMP_minarea * roadBMP_bin[c,r];
    
subject to ag_treat_min {c in comid_all, a in ag_bmp}:
ag_frac[c,a] * area[c,'ag'] >= agBMP_minarea * agBMP_bin[c,a];

subject to graz_treat_min {c in comid_all, g in graz_bmp}:
graz_frac[c,g] * area[c,'graz'] >= grazBMP_minarea * grazBMP_bin[c,g];

subject to urban_treat_min {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] * urban_area[c,d,n,'urban'] >= urbanBMP_minarea * urbanBMP_bin[c,u];
  
subject to ag_frac_const {c in comid_all, a in ag_bmp}:
ag_frac[c,a] <= agBMP_bin[c,a];

subject to graz_frac_const {c in comid_all, g in graz_bmp}:
graz_frac[c,g] <= grazBMP_bin[c,g];
  
subject to urban_frac_const {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] <= urbanBMP_bin[c,u];

#ND added missing 6/3/26;
subject to road_frac_const {c in comid_all, h in road_soil_groups, r in road_bmp}:
    road_frac[c,h,r] <= roadBMP_bin[c,r];

subject to ag_frac_limit {c in comid_all}: 
sum {a in ag_bmp} ag_frac[c,a] <= 1;
# prevents multiple BMPs being implemented on the same area

subject to graz_frac_limit {c in comid_all}: 
sum {g in graz_bmp} graz_frac[c,g] <= 1;
# prevents multiple BMPs being implemented on the same area

#subject to urban_frac_limit {c in comid_all}: 
#sum {u in urban_bmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,u] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - drop
# Per-subarea (d,n) constraint
 subject to urban_frac_limit2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups}:
  sum {u in urban_bmp} urban_frac[c,d,n,u] <= 1;

subject to road_frac_limit {c in comid_all}: 
sum {r in road_bmp, h in road_soil_groups} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - try dropping this because not updated during bootstraps
# Per-soil-group constraint
# subject to road_frac_limit2 {c in comid_all, h in road_soil_groups}:
#  sum {r in road_bmp} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same sub-area

subject to point_dec_limit {c in comid_all}: 
sum {p in point_bmp} point_dec[c,p] <= 1;
# limits each WWTP to one upgrade

subject to total_banks {c in comid_all}:
sum {b in ripbuf_bmp} ripbuf_length[c,b] <=  
   unbuffered_banklength[c,'Forested_Buffer']; #ND 7/8/2026 changed from max
  


subject to roads_and_parkinglots {c in comid_all}:
sum{up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,up] <= max {up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} 
   urban_bmp_implementationpotential[c,d,n,up];


subject to tiledrains {c in comid_all}:
sum{agti in ag_tilebmp} ag_frac[c, agti] <= max {agti in ag_tilebmp}
   ag_bmp_implementationpotential[c,agti];

