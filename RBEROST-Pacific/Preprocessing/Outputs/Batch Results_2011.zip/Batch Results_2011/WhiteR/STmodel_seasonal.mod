#STmodel_seasonal.mod
      
set comid_all :=
{'23980803','23980805','23980807','23980809','23980811','23980813','23980815','23980817','23980819','23980821','23980823','23980825','23980827','23980829','23980831','23980833','23980835','23980837','23980839','23980841','23980843','23980845','23980847','23980849','23980851','23980853','23980855','23980857','23980859','23980861','23980863','23980865','23980867','23980869','23980871','23980873','23980875','23980877','23980879','23980881','23980883','23980885','23980887','23980889','23980891','23980893','23980895','23980897','23980899','23980901','23980903','23980905','23980907','23980909','23980911','23980913','23980915','23980917','23980919','23980921','23980923','23980925','23980927','23980929','23980931','23980933','23980935','23980937','23980939','23980941','23980943','23980945','23980947','23980949','23980951','23980953','23980955','23980957','23980959','23980961','23980963','23980965','23980967','23980969','23980971','23980973','23980975','23980977','23980979','23980981','23980983','23980985','23980987','23980989','23980991','23980993','23980995','23980997','23980999','23981001','23981003','23981005','23981007','23981009','23981011','23981013','23981015','23981017','23981019','23981021','23981023','23981025','23981027','23981029','23981031','23981033','23981035','23981037','23981039','23981041','23981043','23981045','23981047','23981049','23981051','23981053','23981055','23981057','23981059','23981061','23981063','23981065','23981067','23981069','23981071','23981073','23981075','23981077','23981079','23981081','23981083','23981085','23981087','23981089','23981091','23981093','23981095','23981097','23981099','23981101','23981103','23981105','23981107','23981109','23981111','23981113','23981115','23981117','23981119','23981121','23981123','23981125','23981127','23981129','23981131','23981133','23981135','23981137','23981139','23981141','23981143','23981145','23981147','23981149','23981153','23981155','23981157','23981159','23981161','23981163','23981165','23981167','23981169','23981171','23981173','23981175','23981177','23981179','23981181','23981183','23981185','23981187','23981189','23981191','23981193','23981195','23981197','23981199','23981201','23981203','23981205','23981207','23981209','23981211','23981213','23981215','23981217','23981219','23981221','23981223','23981225','23981227','23981229','23981231','23981233','23981235','23981237','23981239','23981241','23981243','23981245','23981247','23981249','23981251','23981253','23981255','23981257','23981259','23981261','23981263','23981265','23981267','23981269','23981271','23981273','23981275','23981277','23981279','23981281','23981283','23981285','23981287','23981289','23981291','23981293','23981295','23981297','23981299','23981301','23981303','23981305','23981307','23981309','23981311','23981313','23981315','23981317','23981319','23981321','23981335','23981337','23981339','23981341','23981365','23981367','23981371','23981373','23981379','23981381','23981383','23981385','23981387','23981411','23981413','23981415','23981417','23981419','23981421','23981423','23981425','23981427','23981429','23981431','23981433','23981435','23981461','23981463','23981465','23981481','23981483','23981485','23981487','23981499','23981501','23981507','23981509','23981511','23981513','23981515','23981517','23981519','23981521','23981523','23981525','23981527','23981529','23981531','23981533','23981535','23981537','23981539','23981541','23981543','23981545','23981547','23981549','23981551','23981553','23981555','23981557','23981559','23981563','23981565','23981567','23981569','23981571','23981573','23981575','23981577','23981579','23981581','23981583','23981585','23981587','23981589','23981593','23981595','23981597','23981599','23981601','23981603','23981605','23981607','23981609','23981611','23981613','23981615','23981617','23981619','23981623','23981627','23981629','23981637','23981643','23981645','23981649','23981653','23981677','23981679','23981683','23981687','23981691','23981693','23981695','23981697','23981699','23981701','23981703','23981705','23981707','23981709','23981713','23981715','23981717','23981719','23981721','23981725','23981727','23981729','23981731','23981733','23981735','23981739','23981743','23981749','23981751','23981753','23981759','23981763','23981765','23981767','23981769','23981771','23981775','23981777','23981779','23981783','23981785','23981787','23981789','23981791','23981793','23981795','23981797','23981801','23981803','23981805','23981809','23981811','23981813','23981815','23981817','23981819','23981821','23981823','23981825','23981829','23981831','23981833','23981837','23981839','23981843','23981845','23981847','23981851','23981853','23981857','23981861','23981865','23981867','23981871','23981873','23981875','23981877','23981879','23981885','23981889','23981891','23981893','23981895','23981901','23981913','23981915','23981917','23981929','23981935','23981937','23981939','23981941','23981945','23981951','23981957','23981959','23981969','23981977','23981981','23981985','23981987','23981989','23981991','23981997','23982015','23982017','23982025','23982027','23982029','23982031','23982033','23982037','23982041','23982043','23982049','23982061','23982065','23982069','23982073','23982079','23982081','23982083','23982087','23982089','23982099','23982101','23982111','23982113','23982127','23982129','23982137','23982141','23982155','23982167','23982171','23982177','23982183','23982187','23982195','23982199','23982203','23982205','23982209','23982215','23982217','23982223','23982227','23982231','23982233','23982235','23982237','23982239','23982245','23982247','23982251','23982253','23982255','23982259','23982261','23982263','23982269','23982271','23982273','23982321','23982337','23982339','23982343','23982345','23982347','23982349','23982355','23982357','23982597','23982611','23982613','23982615','23982617','23982619','23982621'};

set comid_all_N within comid_all := {'23980803','23980805','23980807','23980809','23980811','23980813','23980815','23980817','23980819','23980821','23980823','23980825','23980827','23980829','23980831','23980833','23980835','23980837','23980839','23980841','23980843','23980845','23980847','23980849','23980851','23980853','23980855','23980857','23980859','23980861','23980863','23980865','23980867','23980869','23980871','23980873','23980875','23980877','23980879','23980881','23980883','23980885','23980887','23980889','23980891','23980893','23980895','23980897','23980899','23980901','23980903','23980905','23980907','23980909','23980911','23980913','23980915','23980917','23980919','23980921','23980923','23980925','23980927','23980929','23980931','23980933','23980935','23980937','23980939','23980941','23980943','23980945','23980947','23980949','23980951','23980953','23980955','23980957','23980959','23980961','23980963','23980965','23980967','23980969','23980971','23980973','23980975','23980977','23980979','23980981','23980983','23980985','23980987','23980989','23980991','23980993','23980995','23980997','23980999','23981001','23981003','23981005','23981007','23981009','23981011','23981013','23981015','23981017','23981019','23981021','23981023','23981025','23981027','23981029','23981031','23981033','23981035','23981037','23981039','23981041','23981043','23981045','23981047','23981049','23981051','23981053','23981055','23981057','23981059','23981061','23981063','23981065','23981067','23981069','23981071','23981073','23981075','23981077','23981079','23981081','23981083','23981085','23981087','23981089','23981091','23981093','23981095','23981097','23981099','23981101','23981103','23981105','23981107','23981109','23981111','23981113','23981115','23981117','23981119','23981121','23981123','23981125','23981127','23981129','23981131','23981133','23981135','23981137','23981139','23981141','23981143','23981145','23981147','23981149','23981153','23981155','23981157','23981159','23981161','23981163','23981165','23981167','23981169','23981171','23981173','23981175','23981177','23981179','23981181','23981183','23981185','23981187','23981189','23981191','23981193','23981195','23981197','23981199','23981201','23981203','23981205','23981207','23981209','23981211','23981213','23981215','23981217','23981219','23981221','23981223','23981225','23981227','23981229','23981231','23981233','23981235','23981237','23981239','23981241','23981243','23981245','23981247','23981249','23981251','23981253','23981255','23981257','23981259','23981261','23981263','23981265','23981267','23981269','23981271','23981273','23981275','23981277','23981279','23981281','23981283','23981285','23981287','23981289','23981291','23981293','23981295','23981297','23981299','23981301','23981303','23981305','23981307','23981309','23981311','23981313','23981315','23981317','23981319','23981321','23981335','23981337','23981339','23981341','23981365','23981367','23981371','23981373','23981379','23981381','23981383','23981385','23981387','23981411','23981413','23981415','23981417','23981419','23981421','23981423','23981425','23981427','23981429','23981431','23981433','23981435','23981461','23981463','23981465','23981481','23981483','23981485','23981487','23981499','23981501','23981507','23981509','23981511','23981513','23981515','23981517','23981519','23981521','23981523','23981525','23981527','23981529','23981531','23981533','23981535','23981537','23981539','23981541','23981543','23981545','23981547','23981549','23981551','23981553','23981555','23981557','23981559','23981563','23981565','23981567','23981569','23981571','23981573','23981575','23981577','23981579','23981581','23981583','23981585','23981587','23981589','23981593','23981595','23981597','23981599','23981601','23981603','23981605','23981607','23981609','23981611','23981613','23981615','23981617','23981619','23981623','23981627','23981629','23981637','23981643','23981645','23981649','23981653','23981677','23981679','23981683','23981687','23981691','23981693','23981695','23981697','23981699','23981701','23981703','23981705','23981707','23981709','23981713','23981715','23981717','23981719','23981721','23981725','23981727','23981729','23981731','23981733','23981735','23981739','23981743','23981749','23981751','23981753','23981759','23981763','23981765','23981767','23981769','23981771','23981775','23981777','23981779','23981783','23981785','23981787','23981789','23981791','23981793','23981795','23981797','23981801','23981803','23981805','23981809','23981811','23981813','23981815','23981817','23981819','23981821','23981823','23981825','23981829','23981831','23981833','23981837','23981839','23981843','23981845','23981847','23981851','23981853','23981857','23981861','23981865','23981867','23981871','23981873','23981875','23981877','23981879','23981885','23981889','23981891','23981893','23981895','23981901','23981913','23981915','23981917','23981929','23981935','23981937','23981939','23981941','23981945','23981951','23981957','23981959','23981969','23981977','23981981','23981985','23981987','23981989','23981991','23981997','23982015','23982017','23982025','23982027','23982029','23982031','23982033','23982037','23982041','23982043','23982049','23982061','23982065','23982069','23982073','23982079','23982081','23982083','23982087','23982089','23982099','23982101','23982111','23982113','23982127','23982129','23982137','23982141','23982155','23982167','23982171','23982177','23982183','23982187','23982195','23982199','23982203','23982205','23982209','23982215','23982217','23982223','23982227','23982231','23982233','23982235','23982237','23982239','23982245','23982247','23982251','23982253','23982255','23982259','23982261','23982263','23982269','23982271','23982273','23982321','23982337','23982339','23982343','23982345','23982347','23982349','23982355','23982357','23982597','23982611','23982613','23982615','23982617','23982619','23982621'};

set comid_all_P within comid_all := {};

set comid_N1 within comid_all_N := {'23980803','23980805','23980807','23980809','23980811','23980813','23980815','23980817','23980819','23980821','23980823','23980825','23980827','23980829','23980831','23980833','23980835','23980837','23980839','23980841','23980843','23980845','23980847','23980849','23980851','23980853','23980855','23980857','23980859','23980861','23980863','23980865','23980867','23980869','23980871','23980873','23980875','23980877','23980879','23980881','23980883','23980885','23980887','23980889','23980891','23980893','23980895','23980897','23980899','23980901','23980903','23980905','23980907','23980909','23980911','23980913','23980915','23980917','23980919','23980921','23980923','23980925','23980927','23980929','23980931','23980933','23980935','23980937','23980939','23980941','23980943','23980945','23980947','23980949','23980951','23980953','23980955','23980957','23980959','23980961','23980963','23980965','23980967','23980969','23980971','23980973','23980975','23980977','23980979','23980981','23980983','23980985','23980987','23980989','23980991','23980993','23980995','23980997','23980999','23981001','23981003','23981005','23981007','23981009','23981011','23981013','23981015','23981017','23981019','23981021','23981023','23981025','23981027','23981029','23981031','23981033','23981035','23981037','23981039','23981041','23981043','23981045','23981047','23981049','23981051','23981053','23981055','23981057','23981059','23981061','23981063','23981065','23981067','23981069','23981071','23981073','23981075','23981077','23981079','23981081','23981083','23981085','23981087','23981089','23981091','23981093','23981095','23981097','23981099','23981101','23981103','23981105','23981107','23981109','23981111','23981113','23981115','23981117','23981119','23981121','23981123','23981125','23981127','23981129','23981131','23981133','23981135','23981137','23981139','23981141','23981143','23981145','23981147','23981149','23981153','23981155','23981157','23981159','23981161','23981163','23981165','23981167','23981169','23981171','23981173','23981175','23981177','23981179','23981181','23981183','23981185','23981187','23981189','23981191','23981193','23981195','23981197','23981199','23981201','23981203','23981205','23981207','23981209','23981211','23981213','23981215','23981217','23981219','23981221','23981223','23981225','23981227','23981229','23981231','23981233','23981235','23981237','23981239','23981241','23981243','23981245','23981247','23981249','23981251','23981253','23981255','23981257','23981259','23981261','23981263','23981265','23981267','23981269','23981271','23981273','23981275','23981277','23981279','23981281','23981283','23981285','23981287','23981289','23981291','23981293','23981295','23981297','23981299','23981301','23981303','23981305','23981307','23981309','23981311','23981313','23981315','23981317','23981319','23981321','23981335','23981337','23981339','23981341','23981365','23981367','23981371','23981373','23981379','23981381','23981383','23981385','23981387','23981411','23981413','23981415','23981417','23981419','23981421','23981423','23981425','23981427','23981429','23981431','23981433','23981435','23981461','23981463','23981465','23981481','23981483','23981485','23981487','23981499','23981501','23981507','23981509','23981511','23981513','23981515','23981517','23981519','23981521','23981523','23981525','23981527','23981529','23981531','23981533','23981535','23981537','23981539','23981541','23981543','23981545','23981547','23981549','23981551','23981553','23981555','23981557','23981559','23981563','23981565','23981567','23981569','23981571','23981573','23981575','23981577','23981579','23981581','23981583','23981585','23981587','23981589','23981593','23981595','23981597','23981599','23981601','23981603','23981605','23981607','23981609','23981611','23981613','23981615','23981617','23981619','23981623','23981627','23981629','23981637','23981643','23981645','23981649','23981653','23981677','23981679','23981683','23981687','23981691','23981693','23981695','23981697','23981699','23981701','23981703','23981705','23981707','23981709','23981713','23981715','23981717','23981719','23981721','23981725','23981727','23981729','23981731','23981733','23981735','23981739','23981743','23981749','23981751','23981753','23981759','23981763','23981765','23981767','23981769','23981771','23981775','23981777','23981779','23981783','23981785','23981787','23981789','23981791','23981793','23981795','23981797','23981801','23981803','23981805','23981809','23981811','23981813','23981815','23981817','23981819','23981821','23981823','23981825','23981829','23981831','23981833','23981837','23981839','23981843','23981845','23981847','23981851','23981853','23981857','23981861','23981865','23981867','23981871','23981873','23981875','23981877','23981879','23981885','23981889','23981891','23981893','23981895','23981901','23981913','23981915','23981917','23981929','23981935','23981937','23981939','23981941','23981945','23981951','23981957','23981959','23981969','23981977','23981981','23981985','23981987','23981989','23981991','23981997','23982015','23982017','23982025','23982027','23982029','23982031','23982033','23982037','23982041','23982043','23982049','23982061','23982065','23982069','23982073','23982079','23982081','23982083','23982087','23982089','23982099','23982101','23982111','23982113','23982127','23982129','23982137','23982141','23982155','23982167','23982171','23982177','23982183','23982187','23982195','23982199','23982203','23982205','23982209','23982215','23982217','23982223','23982227','23982231','23982233','23982235','23982237','23982239','23982245','23982247','23982251','23982253','23982255','23982259','23982261','23982263','23982269','23982271','23982273','23982321','23982337','23982339','23982343','23982345','23982347','23982349','23982355','23982357','23982597','23982611','23982613','23982615','23982617','23982619','23982621'};

set comid_P1 within comid_all_P := {};

set seasons := 1..4 ordered; 

set years := 6..7 ordered;

set urban_land_uses := {'UIDU','URHD','URLD','URMD'};

set urban_soil_groups := {'A','B','C','D'};

set road_soil_groups := {'A','B','C','D'};


set urban_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Green_Roof','Infiltration_Basin','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set urban_pervbmp within urban_bmp :=
{'Porous_Pavement_w_UD'};

set road_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Infiltration_Basin','Infiltration_Chamber','Infiltration_Trench','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set ag_bmp :=
{'Conservation','Contour_Farming','Fert_75','Fert_90','Filterstrip','MIN_TILL','Terrace_Waterway','Terrace_Only','Waterway_Only','Grade_Stabilization','Diversion','Cover_Crops','Drainage_Management','Manure_Injection'};

set ag_tilebmp within ag_bmp :=
{'Drainage_Management'};

set septic_bmp :=
{'none'};

set graz_bmp :=
{'Offsite_Water'};

set ripbuf_bmp :=
{'Grassed_Buffer','Forested_Buffer'};

set point_bmp :=
{'C','C_F','FOURBDP_M','FOURBDP_M_C_F','MLE','MLE_C','C_M','M','SBR','SBR_C','SBR_C_F','SBR_DNF_C_F_M','SBR_DNF_M','FOURBDP_MBR_M','FOURBDP_MBR_M_C','MLE_MBR','MLE_MBR_C'};

set loads_all :=
{'point', 'urban', 'road', 'ag', 'septic', 'graz', 'storage', 'other'};
  
set area_sub :=
{'ag', 'graz'};
set urban_area_sub :=
{'urban'};
set road_area_sub :=
{'road'};

set transfer_types := {'coeff', 'notrib'};

set loads_riparian := 
 {'riparian'};

set limits := 
 {'limits'};

set total_load := 
 {'total_load'};

set other_loads := 
 {'other_load'};

set septic_bmp_totals := 
 {'total_parcels'};

param baseloads_N1 {comid_N1, seasons, years, loads_all} >= 0;
param riparianload_N1 {comid_N1, seasons, years, loads_riparian} >= 0;

param septic_bmp_implementationpotential {comid_all_N, septic_bmp} >= 0;
param septic_bmp_implementationtotal {comid_all_N, septic_bmp_totals} >= 0;

param area {comid_all, area_sub} >=0;
    
param urban_area {comid_all, urban_land_uses, urban_soil_groups, urban_area_sub} >=0;
param road_area {comid_all, road_soil_groups, road_area_sub} >=0;
param urban_bmp_implementationpotential {comid_all, urban_land_uses, urban_soil_groups, urban_bmp} >= 0;
# ND 7/20/26 added
param road_bmp_implementationpotential {comid_all, road_soil_groups, road_bmp} >= 0;
param ag_bmp_implementationpotential {comid_all, ag_bmp} >= 0;
param unbuffered_banklength {comid_all, ripbuf_bmp} >= 0;
param total_banklength {comid_all} >= 0;

param ag_costs_capital {comid_all, ag_bmp};
param ag_costs_operations {comid_all, ag_bmp};
param graz_costs_capital {comid_all, graz_bmp};
param graz_costs_operations {comid_all, graz_bmp};
param point_costs_capital {comid_all, point_bmp};
param point_costs_operations {comid_all, point_bmp};
param urban_costs_capital {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param urban_costs_operations {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param road_costs_capital {comid_all, road_soil_groups, road_bmp};
param road_costs_operations {comid_all, road_soil_groups, road_bmp};
param ripbuf_costs_capital {comid_all, ripbuf_bmp};
param ripbuf_costs_operations {comid_all, ripbuf_bmp};

param septic_costs_capital {comid_all_N, septic_bmp} >= 0;
param septic_costs_operations {comid_all_N, septic_bmp} >= 0;



param ag_effic_N {comid_all_N, ag_bmp};
param graz_effic_N {comid_all_N, graz_bmp};
param point_effic_N {comid_all_N, point_bmp};
param urban_effic_N {comid_all_N, seasons, years, urban_land_uses, urban_soil_groups, urban_bmp};
param road_effic_N {comid_all_N, seasons, years, road_soil_groups, road_bmp};
param septic_effic_N {comid_all_N, septic_bmp};

param riparianremoval_N1 {c in comid_N1, s in seasons, y in years, b in ripbuf_bmp};
param loads_lim_N1 {seasons, years, limits} >= 0;


param transfer_coefficients_N1 {comid_N1, seasons, years, transfer_types};

param total_load_N1 {s in seasons, y in years, total_load} >= 0;


param agcost_frac >=0;
    
param agBMP_minarea;
param grazBMP_minarea;
param urbanBMP_minarea;
param roadBMP_minarea;

param urban_frac_min {urban_bmp} >=0, <= 1;
param urban_frac_max {u in urban_bmp} >= urban_frac_min[u], <= 1;
param road_frac_min {road_bmp} >=0, <= 1;
param road_frac_max {r in road_bmp} >= road_frac_min[r], <= 1;
param ag_frac_min {ag_bmp} >= 0, <= 1;
param ag_frac_max {a in ag_bmp} >= ag_frac_min[a], <= 1;
param graz_frac_min {graz_bmp} >= 0, <= 1;
param graz_frac_max {g in graz_bmp} >= graz_frac_min[g], <= 1;
param ripbuf_frac_min {ripbuf_bmp} >= 0, <= 1;
param ripbuf_frac_max {b in ripbuf_bmp} >= ripbuf_frac_min[b], <= 1;
  
param ps_coef {c in comid_all, p in point_bmp} := (point_costs_capital[c, p] + 
    point_costs_operations[c, p]);
param urban_coef {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} := urban_area[c,d,n,'urban'] * 
  (urban_costs_capital[c,d,n,u] + urban_costs_operations[c,d,n,u]) ;
param road_coef {c in comid_all, h in road_soil_groups, r in road_bmp} := road_area[c,h,'road'] * 
  (road_costs_capital[c,h,r] + road_costs_operations[c,h,r]) ;
param ag_coef {c in comid_all,  a in ag_bmp} := agcost_frac * area[c,'ag'] * 
  (ag_costs_capital[c,a] + ag_costs_operations[c,a]) ;

param graz_coef {c in comid_all, g in graz_bmp} := agcost_frac * area[c,'graz'] * 
  (graz_costs_capital[c,g] + graz_costs_operations[c,g]) ;
param ripbuf_coef {c in comid_all, b in ripbuf_bmp} := 
  agcost_frac * (ripbuf_costs_capital[c, b] + ripbuf_costs_operations[c, b]);
  
var agBMP_bin {comid_all, ag_bmp} binary;
var grazBMP_bin {comid_all, graz_bmp} binary;
var urbanBMP_bin {comid_all, urban_bmp} binary;
var roadBMP_bin {comid_all, road_bmp} binary;

var point_dec {c in comid_all, p in point_bmp} binary;
# correct unbounded fraction variables - AI solution created NEOS error  
var urban_frac {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}
  >= 0, <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u];
#  := 0; # default is 0 so not needed; 
#    >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u],  
#    <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u],
#    :=0;
var ag_frac {c in comid_all, a in ag_bmp}
   >= 0,
   <= ag_frac_max[a] * ag_bmp_implementationpotential[c,a];
#   := 0
#    >= ag_frac_min[a] * ag_bmp_implementationpotential[c, a],  
#    <= ag_frac_max[a] * ag_bmp_implementationpotential[c, a],
#    :=0;
# ND 7/20/26 Added road_bmp_implementationpotential
var road_frac {c in comid_all, h in road_soil_groups, r in road_bmp}
  >= 0, 
  <= road_frac_max[r] * road_bmp_implementationpotential[c,h,r];
#  := 0;  
#   >= road_frac_min[r],
#   <= road_frac_max[r],
#   :=0;
var graz_frac {c in comid_all, g in graz_bmp}
  >= 0,
  <= graz_frac_max[g];
#  := 0;
#   >= graz_frac_min[g],
#   <= graz_frac_max[g],
#   :=0;
var ripbuf_length {c in comid_all, b in ripbuf_bmp} 
   >= 0, 
   <= unbuffered_banklength[c, b] * ripbuf_frac_max[b];
#   := 0;
   

var inc_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;
var no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_ag_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_graz_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_urb_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_road_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            subject to road_load_upper {c in comid_N1, s in seasons, y in years}:

              reduced_road_load_N1[c,s,y] <= baseloads_N1[c,s,y,'road'];


subject to road_load_lower {c in comid_N1, s in seasons, y in years}:
    reduced_road_load_N1[c,s,y] >=
        baseloads_N1[c,s,y,'road'] *
        (1 - sum {h in road_soil_groups, r in road_bmp}
              road_effic_N[c,s,y,h,r] * road_frac[c,h,r]);

            
            
            
            var reduced_point_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_septic_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

minimize cost: sum {c in comid_all, p in point_bmp} (ps_coef[c,p] * point_dec[c,p]) +
sum {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} (urban_coef[c,d,n,u] * urban_frac[c,d,n,u]) +
sum {c in comid_all, h in road_soil_groups, r in road_bmp} (road_coef[c,h,r] * road_frac[c,h,r]) +
sum {c in comid_all, a in ag_bmp} (ag_coef[c,a] * ag_frac[c,a]) +
sum {c in comid_all, g in graz_bmp} (graz_coef[c,g] * graz_frac[c,g]) +
 

sum {c in comid_all, b in ripbuf_bmp} (ripbuf_coef[c, b] * ripbuf_length[c, b]);
subject to calc_red_ag_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_ag_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'ag'] * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a]));

  
    subject to calc_red_graz_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_graz_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'graz'] * (1 - sum {g in graz_bmp}(graz_effic_N[c,g] * graz_frac[c,g]));

  
    subject to calc_red_urb_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_urb_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'urban'] * (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}(urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]));

      
    subject to road_removal_cap_N1{c in comid_N1, s in seasons, y in years}:
    sum {h in road_soil_groups, r in road_bmp}

        road_effic_N[c,s,y,h,r] * road_frac[c,h,r] <= 1;

  
    subject to calc_red_road_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_road_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'road'] * (1 - sum{h in road_soil_groups, r in road_bmp}(road_effic_N[c,s,y,h,r] * road_frac[c,h,r]));
 
    
    subject to calc_red_point_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_point_load_N1[c,s,y] = 
 
        (baseloads_N1[c,s,y,'point'] + 0)  * (1 - sum{p in point_bmp}(point_effic_N[c,p] * point_dec[c,p]));

          
    subject to calc_red_septic_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_septic_load_N1[c,s,y] =
0;

          
    subject to calc_riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years}:
          riparian_reduction_load_N1[c,s,y] =  
          sum {b in ripbuf_bmp}

        ripbuf_length[c,b] * riparianremoval_N1[c,s,y,b];
          #*

          # (
          #   reduced_ag_load_N1[c,s,y] / riparianload_N1[c,s,y,'riparian']

          #   +

          #     (1 - sum {d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}

          #      urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u])

          #   * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag'])

          #   / riparianload_N1[c,s,y,'riparian']

          # );

  
      subject to calc_no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years}:

          no_storage_NPSload_N1[c,s,y] =
          baseloads_N1[c,s,y,'other'] +
          reduced_ag_load_N1[c,s,y] + 
          reduced_urb_load_N1[c,s,y] +   
          reduced_road_load_N1[c,s,y] +
          reduced_point_load_N1[c,s,y] +
          reduced_septic_load_N1[c,s,y] -
          riparian_reduction_load_N1[c,s,y];
 
          
      subject to calc_red_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_storage_load_N1[c,s,y] =

        if transfer_coefficients_N1[c,s,y,'notrib'] = 1 then
 
          (no_storage_NPSload_N1[c,s,y] * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 && s = first(seasons) then

          if y = first(years) then
            baseloads_N1[c,s,y,'storage']

          else if y != first(years) then

            (no_storage_NPSload_N1[c,4,y-1] 
            * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 && s != first(seasons) then

          (no_storage_NPSload_N1[c,s-1,y] 
* transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff']);

    
    subject to calc_inc_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      inc_storage_load_N1[c,s,y] =

        reduced_storage_load_N1[c,s,y] + 
        reduced_ag_load_N1[c,s,y] + 
        reduced_urb_load_N1[c,s,y] +   
        reduced_road_load_N1[c,s,y] +
        reduced_point_load_N1[c,s,y] +
        reduced_septic_load_N1[c,s,y] -
        riparian_reduction_load_N1[c,s,y];

    
subject to total_loads_N1{s in seasons, y in years}:
sum{c in comid_N1} (inc_storage_load_N1[c,s,7]) <= loads_lim_N1[s,7,'limits'];

subject to riparian_loads_N1 {c in comid_N1, s in seasons, y in years}:
sum {b in ripbuf_bmp} ripbuf_length[c, b] * riparianremoval_N1[c,s,y,b] <= 
 
            (baseloads_N1[c,s,y,'ag'] 
 
            * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a])) 

            + (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} 

              (urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]))
 
            * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag']));

subject to urban_frac_min2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u] * urbanBMP_bin[c,u];
    subject to ag_frac_min2 {c in comid_all, a in ag_bmp}:
ag_frac[c,a] >= ag_frac_min[a] * ag_bmp_implementationpotential[c,a] * agBMP_bin[c,a];
    subject to graz_frac_min2{c in comid_all,g in graz_bmp}:
graz_frac[c,g] >= graz_frac_min[g] * grazBMP_bin[c,g];

#    subject to road_frac_min2{c in comid_all, h in road_soil_groups,r in road_bmp}:
# road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND replacement
  subject to road_frac_min2 {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND added Aggregate min area per BMP (recommended) 
  subject to road_treat_min {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] * road_area[c,h,'road'] >= roadBMP_minarea * roadBMP_bin[c,r];
    
subject to ag_treat_min {c in comid_all, a in ag_bmp}:
ag_frac[c,a] * area[c,'ag'] >= agBMP_minarea * agBMP_bin[c,a];

subject to graz_treat_min {c in comid_all, g in graz_bmp}:
graz_frac[c,g] * area[c,'graz'] >= grazBMP_minarea * grazBMP_bin[c,g];

subject to urban_treat_min {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] * urban_area[c,d,n,'urban'] >= urbanBMP_minarea * urbanBMP_bin[c,u];
  
subject to ag_frac_const {c in comid_all, a in ag_bmp}:
ag_frac[c,a] <= agBMP_bin[c,a];

subject to graz_frac_const {c in comid_all, g in graz_bmp}:
graz_frac[c,g] <= grazBMP_bin[c,g];
  
subject to urban_frac_const {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] <= urbanBMP_bin[c,u];

#ND added missing 6/3/26;
subject to road_frac_const {c in comid_all, h in road_soil_groups, r in road_bmp}:
    road_frac[c,h,r] <= roadBMP_bin[c,r];

subject to ag_frac_limit {c in comid_all}: 
sum {a in ag_bmp} ag_frac[c,a] <= 1;
# prevents multiple BMPs being implemented on the same area

subject to graz_frac_limit {c in comid_all}: 
sum {g in graz_bmp} graz_frac[c,g] <= 1;
# prevents multiple BMPs being implemented on the same area

#subject to urban_frac_limit {c in comid_all}: 
#sum {u in urban_bmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,u] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - drop
# Per-subarea (d,n) constraint
 subject to urban_frac_limit2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups}:
  sum {u in urban_bmp} urban_frac[c,d,n,u] <= 1;

subject to road_frac_limit {c in comid_all}: 
sum {r in road_bmp, h in road_soil_groups} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - try dropping this because not updated during bootstraps
# Per-soil-group constraint
# subject to road_frac_limit2 {c in comid_all, h in road_soil_groups}:
#  sum {r in road_bmp} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same sub-area

subject to point_dec_limit {c in comid_all}: 
sum {p in point_bmp} point_dec[c,p] <= 1;
# limits each WWTP to one upgrade

subject to total_banks {c in comid_all}:
sum {b in ripbuf_bmp} ripbuf_length[c,b] <=  
   unbuffered_banklength[c,'Forested_Buffer']; #ND 7/8/2026 changed from max
  


subject to roads_and_parkinglots {c in comid_all}:
sum{up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,up] <= max {up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} 
   urban_bmp_implementationpotential[c,d,n,up];


subject to tiledrains {c in comid_all}:
sum{agti in ag_tilebmp} ag_frac[c, agti] <= max {agti in ag_tilebmp}
   ag_bmp_implementationpotential[c,agti];

