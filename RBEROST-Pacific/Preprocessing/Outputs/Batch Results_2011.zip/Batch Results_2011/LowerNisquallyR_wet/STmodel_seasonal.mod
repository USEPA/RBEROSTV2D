#STmodel_seasonal.mod
      
set comid_all :=
{'23989433','23989435','23989437','23989439','23989451','23989453','23989455','24281956','24281958','24281960','24281962','24281964','24281966','24281968','24281970','24281972','24281974','24281976','24281978','24281980','24281982','24281984','24281986','24281988','24281990','24281992','24281994','24281996','24281998','24282000','24282002','24282004','24282006','24282008','24282010','24282012','24282014','24282016','24282018','24282020','24282022','24282024','24282026','24282028','24282030','24282032','24282034','24282036','24282038','24282040','24282042','24282044','24282046','24282048','24282050','24282052','24282054','24282056','24282058','24282060','24282062','24282268','24282270','24282272','24282274','24282276','24282278','24282280','24282282','24282284','24282286','24282288','24282290','24282292','24282294','24282296','24282298','24282300','24282302','24282304','24282306','24282308','24282310','24282312','24282314','24282316','24282318','24282320','24282322','24282324','24282326','24282328','24282330','24282332','24282334','24282336','24282338','24282340','24282342','24282344','24282346','24282348','24282350','24282352','24282354','24282356','24282358','24282360','24282362','24282364','24282366','24282372','24282374','24282376','24282378','24282380','24282412','24282414','24282416','24282418','24282420','24282424','24282426','24282428','24282430','24282432','24282434','24282436','24282438','24282440','24282442','24282444','24282446','24282448','24282450','24282452','24282454','24282456','24282458','24282460','24282462','24282464','24282466','24282468','24282470','24282474','24282476','24282478','24282480','24282482','24282484','24282486','24282488','24282490','24282492','24282494','24282496','24282498','24282500','24282502','24282504','24282506','24282508','24282510','24282512','24282514','24282516','24282518','24282520','24282524','24282528','24282530','24282532','24282534','24282536','24282542','24282546','24282548','24282550','24282552','24282554','24282556','24282558','24282560','24282562','24282564','24282566','24282568','24282570','24282572','24282574','24282576','24282578','24282580','24282582','24282584','24282586','24282588','24282590','24282594','24282596','24282598','24282602','24282606','24282608','24282610','24282612','24282616','24282618','24282620','24282622','24282624','24282626','24282628','24282630','24282632','24282634','24282638','24282640','24282644','24282674','24282702','24282712','24282724','24282728','24282748','24282750','24282760','24282768','24282788','24282798','24282838','24282840','24282842','24282844','24282846','24282848','24282852','24282854','24282856','24282858','24282860','24282862','24282864','24282866','24282868','24282870','24282872','24282874','24282876','24282878','24282882','24282888','24282894','24282896','24282898','24282900','24282902','24282904','24282906','24282908','24282910','24282914','24282916','24282946','24282956','24282978','24283010','24283016','24283026'};

set comid_all_N within comid_all := {'23989433','23989435','23989437','23989439','23989451','23989453','23989455','24281956','24281958','24281960','24281962','24281964','24281966','24281968','24281970','24281972','24281974','24281976','24281978','24281980','24281982','24281984','24281986','24281988','24281990','24281992','24281994','24281996','24281998','24282000','24282002','24282004','24282006','24282008','24282010','24282012','24282014','24282016','24282018','24282020','24282022','24282024','24282026','24282028','24282030','24282032','24282034','24282036','24282038','24282040','24282042','24282044','24282046','24282048','24282050','24282052','24282054','24282056','24282058','24282060','24282062','24282268','24282270','24282272','24282274','24282276','24282278','24282280','24282282','24282284','24282286','24282288','24282290','24282292','24282294','24282296','24282298','24282300','24282302','24282304','24282306','24282308','24282310','24282312','24282314','24282316','24282318','24282320','24282322','24282324','24282326','24282328','24282330','24282332','24282334','24282336','24282338','24282340','24282342','24282344','24282346','24282348','24282350','24282352','24282354','24282356','24282358','24282360','24282362','24282364','24282366','24282372','24282374','24282376','24282378','24282380','24282412','24282414','24282416','24282418','24282420','24282424','24282426','24282428','24282430','24282432','24282434','24282436','24282438','24282440','24282442','24282444','24282446','24282448','24282450','24282452','24282454','24282456','24282458','24282460','24282462','24282464','24282466','24282468','24282470','24282474','24282476','24282478','24282480','24282482','24282484','24282486','24282488','24282490','24282492','24282494','24282496','24282498','24282500','24282502','24282504','24282506','24282508','24282510','24282512','24282514','24282516','24282518','24282520','24282524','24282528','24282530','24282532','24282534','24282536','24282542','24282546','24282548','24282550','24282552','24282554','24282556','24282558','24282560','24282562','24282564','24282566','24282568','24282570','24282572','24282574','24282576','24282578','24282580','24282582','24282584','24282586','24282588','24282590','24282594','24282596','24282598','24282602','24282606','24282608','24282610','24282612','24282616','24282618','24282620','24282622','24282624','24282626','24282628','24282630','24282632','24282634','24282638','24282640','24282644','24282674','24282702','24282712','24282724','24282728','24282748','24282750','24282760','24282768','24282788','24282798','24282838','24282840','24282842','24282844','24282846','24282848','24282852','24282854','24282856','24282858','24282860','24282862','24282864','24282866','24282868','24282870','24282872','24282874','24282876','24282878','24282882','24282888','24282894','24282896','24282898','24282900','24282902','24282904','24282906','24282908','24282910','24282914','24282916','24282946','24282956','24282978','24283010','24283016','24283026'};

set comid_all_P within comid_all := {};

set comid_N1 within comid_all_N := {'23989433','23989435','23989437','23989439','23989451','23989453','23989455','24281956','24281958','24281960','24281962','24281964','24281966','24281968','24281970','24281972','24281974','24281976','24281978','24281980','24281982','24281984','24281986','24281988','24281990','24281992','24281994','24281996','24281998','24282000','24282002','24282004','24282006','24282008','24282010','24282012','24282014','24282016','24282018','24282020','24282022','24282024','24282026','24282028','24282030','24282032','24282034','24282036','24282038','24282040','24282042','24282044','24282046','24282048','24282050','24282052','24282054','24282056','24282058','24282060','24282062','24282268','24282270','24282272','24282274','24282276','24282278','24282280','24282282','24282284','24282286','24282288','24282290','24282292','24282294','24282296','24282298','24282300','24282302','24282304','24282306','24282308','24282310','24282312','24282314','24282316','24282318','24282320','24282322','24282324','24282326','24282328','24282330','24282332','24282334','24282336','24282338','24282340','24282342','24282344','24282346','24282348','24282350','24282352','24282354','24282356','24282358','24282360','24282362','24282364','24282366','24282372','24282374','24282376','24282378','24282380','24282412','24282414','24282416','24282418','24282420','24282424','24282426','24282428','24282430','24282432','24282434','24282436','24282438','24282440','24282442','24282444','24282446','24282448','24282450','24282452','24282454','24282456','24282458','24282460','24282462','24282464','24282466','24282468','24282470','24282474','24282476','24282478','24282480','24282482','24282484','24282486','24282488','24282490','24282492','24282494','24282496','24282498','24282500','24282502','24282504','24282506','24282508','24282510','24282512','24282514','24282516','24282518','24282520','24282524','24282528','24282530','24282532','24282534','24282536','24282542','24282546','24282548','24282550','24282552','24282554','24282556','24282558','24282560','24282562','24282564','24282566','24282568','24282570','24282572','24282574','24282576','24282578','24282580','24282582','24282584','24282586','24282588','24282590','24282594','24282596','24282598','24282602','24282606','24282608','24282610','24282612','24282616','24282618','24282620','24282622','24282624','24282626','24282628','24282630','24282632','24282634','24282638','24282640','24282644','24282674','24282702','24282712','24282724','24282728','24282748','24282750','24282760','24282768','24282788','24282798','24282838','24282840','24282842','24282844','24282846','24282848','24282852','24282854','24282856','24282858','24282860','24282862','24282864','24282866','24282868','24282870','24282872','24282874','24282876','24282878','24282882','24282888','24282894','24282896','24282898','24282900','24282902','24282904','24282906','24282908','24282910','24282914','24282916','24282946','24282956','24282978','24283010','24283016','24283026'};

set comid_P1 within comid_all_P := {};

set seasons := 1..4 ordered; 

set years := 14..15 ordered;

set urban_land_uses := {'UIDU','URHD','URLD','URMD'};

set urban_soil_groups := {'A','B','C','D'};

set road_soil_groups := {'A','B','C','D'};


set urban_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Green_Roof','Infiltration_Basin','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set urban_pervbmp within urban_bmp :=
{'Porous_Pavement_w_UD'};

set road_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Infiltration_Basin','Infiltration_Chamber','Infiltration_Trench','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set ag_bmp :=
{'Conservation','Contour_Farming','Fert_75','Fert_90','Filterstrip','MIN_TILL','Terrace_Waterway','Terrace_Only','Waterway_Only','Grade_Stabilization','Diversion','Cover_Crops','Drainage_Management','Manure_Injection'};

set ag_tilebmp within ag_bmp :=
{'Drainage_Management'};

set septic_bmp :=
{'none'};

set graz_bmp :=
{'Offsite_Water'};

set ripbuf_bmp :=
{'Grassed_Buffer','Forested_Buffer'};

set point_bmp :=
{'C','C_F','FOURBDP_M','FOURBDP_M_C_F','MLE','MLE_C','C_M','M','SBR','SBR_C','SBR_C_F','SBR_DNF_C_F_M','SBR_DNF_M','FOURBDP_MBR_M','FOURBDP_MBR_M_C','MLE_MBR','MLE_MBR_C'};

set loads_all :=
{'point', 'urban', 'road', 'ag', 'septic', 'graz', 'storage', 'other'};
  
set area_sub :=
{'ag', 'graz'};
set urban_area_sub :=
{'urban'};
set road_area_sub :=
{'road'};

set transfer_types := {'coeff', 'notrib'};

set loads_riparian := 
 {'riparian'};

set limits := 
 {'limits'};

set total_load := 
 {'total_load'};

set other_loads := 
 {'other_load'};

set septic_bmp_totals := 
 {'total_parcels'};

param baseloads_N1 {comid_N1, seasons, years, loads_all} >= 0;
param riparianload_N1 {comid_N1, seasons, years, loads_riparian} >= 0;

param septic_bmp_implementationpotential {comid_all_N, septic_bmp} >= 0;
param septic_bmp_implementationtotal {comid_all_N, septic_bmp_totals} >= 0;

param area {comid_all, area_sub} >=0;
    
param urban_area {comid_all, urban_land_uses, urban_soil_groups, urban_area_sub} >=0;
param road_area {comid_all, road_soil_groups, road_area_sub} >=0;
param urban_bmp_implementationpotential {comid_all, urban_land_uses, urban_soil_groups, urban_bmp} >= 0;
# ND 7/20/26 added
param road_bmp_implementationpotential {comid_all, road_soil_groups, road_bmp} >= 0;
param ag_bmp_implementationpotential {comid_all, ag_bmp} >= 0;
param unbuffered_banklength {comid_all, ripbuf_bmp} >= 0;
param total_banklength {comid_all} >= 0;

param ag_costs_capital {comid_all, ag_bmp};
param ag_costs_operations {comid_all, ag_bmp};
param graz_costs_capital {comid_all, graz_bmp};
param graz_costs_operations {comid_all, graz_bmp};
param point_costs_capital {comid_all, point_bmp};
param point_costs_operations {comid_all, point_bmp};
param urban_costs_capital {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param urban_costs_operations {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param road_costs_capital {comid_all, road_soil_groups, road_bmp};
param road_costs_operations {comid_all, road_soil_groups, road_bmp};
param ripbuf_costs_capital {comid_all, ripbuf_bmp};
param ripbuf_costs_operations {comid_all, ripbuf_bmp};

param septic_costs_capital {comid_all_N, septic_bmp} >= 0;
param septic_costs_operations {comid_all_N, septic_bmp} >= 0;



param ag_effic_N {comid_all_N, ag_bmp};
param graz_effic_N {comid_all_N, graz_bmp};
param point_effic_N {comid_all_N, point_bmp};
param urban_effic_N {comid_all_N, seasons, years, urban_land_uses, urban_soil_groups, urban_bmp};
param road_effic_N {comid_all_N, seasons, years, road_soil_groups, road_bmp};
param septic_effic_N {comid_all_N, septic_bmp};

param riparianremoval_N1 {c in comid_N1, s in seasons, y in years, b in ripbuf_bmp};
param loads_lim_N1 {seasons, years, limits} >= 0;


param transfer_coefficients_N1 {comid_N1, seasons, years, transfer_types};


param total_load_N1 {s in seasons, y in years, total_load} >= 0;


param agcost_frac >=0;
    
param agBMP_minarea;
param grazBMP_minarea;
param urbanBMP_minarea;
param roadBMP_minarea;

param urban_frac_min {urban_bmp} >=0, <= 1;
param urban_frac_max {u in urban_bmp} >= urban_frac_min[u], <= 1;
param road_frac_min {road_bmp} >=0, <= 1;
param road_frac_max {r in road_bmp} >= road_frac_min[r], <= 1;
param ag_frac_min {ag_bmp} >= 0, <= 1;
param ag_frac_max {a in ag_bmp} >= ag_frac_min[a], <= 1;
param graz_frac_min {graz_bmp} >= 0, <= 1;
param graz_frac_max {g in graz_bmp} >= graz_frac_min[g], <= 1;
param ripbuf_frac_min {ripbuf_bmp} >= 0, <= 1;
param ripbuf_frac_max {b in ripbuf_bmp} >= ripbuf_frac_min[b], <= 1;
  
param ps_coef {c in comid_all, p in point_bmp} := (point_costs_capital[c, p] + 
    point_costs_operations[c, p]);
param urban_coef {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} := urban_area[c,d,n,'urban'] * 
  (urban_costs_capital[c,d,n,u] + urban_costs_operations[c,d,n,u]) ;
param road_coef {c in comid_all, h in road_soil_groups, r in road_bmp} := road_area[c,h,'road'] * 
  (road_costs_capital[c,h,r] + road_costs_operations[c,h,r]) ;
param ag_coef {c in comid_all,  a in ag_bmp} := agcost_frac * area[c,'ag'] * 
  (ag_costs_capital[c,a] + ag_costs_operations[c,a]) ;

param graz_coef {c in comid_all, g in graz_bmp} := agcost_frac * area[c,'graz'] * 
  (graz_costs_capital[c,g] + graz_costs_operations[c,g]) ;
param ripbuf_coef {c in comid_all, b in ripbuf_bmp} := 
  agcost_frac * (ripbuf_costs_capital[c, b] + ripbuf_costs_operations[c, b]);
  
var agBMP_bin {comid_all, ag_bmp} binary;
var grazBMP_bin {comid_all, graz_bmp} binary;
var urbanBMP_bin {comid_all, urban_bmp} binary;
var roadBMP_bin {comid_all, road_bmp} binary;

var point_dec {c in comid_all, p in point_bmp} binary;
# correct unbounded fraction variables - AI solution created NEOS error  
var urban_frac {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}
  >= 0, <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u];
#  := 0; # default is 0 so not needed; 
#    >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u],  
#    <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u],
#    :=0;
var ag_frac {c in comid_all, a in ag_bmp}
   >= 0,
   <= ag_frac_max[a] * ag_bmp_implementationpotential[c,a];
#   := 0
#    >= ag_frac_min[a] * ag_bmp_implementationpotential[c, a],  
#    <= ag_frac_max[a] * ag_bmp_implementationpotential[c, a],
#    :=0;
# ND 7/20/26 Added road_bmp_implementationpotential
var road_frac {c in comid_all, h in road_soil_groups, r in road_bmp}
  >= 0, 
  <= road_frac_max[r] * road_bmp_implementationpotential[c,h,r];
#  := 0;  
#   >= road_frac_min[r],
#   <= road_frac_max[r],
#   :=0;
var graz_frac {c in comid_all, g in graz_bmp}
  >= 0,
  <= graz_frac_max[g];
#  := 0;
#   >= graz_frac_min[g],
#   <= graz_frac_max[g],
#   :=0;
var ripbuf_length {c in comid_all, b in ripbuf_bmp} 
   >= 0, 
   <= unbuffered_banklength[c, b] * ripbuf_frac_max[b];
#   := 0;
   

var inc_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;
var no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_ag_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_graz_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_urb_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_road_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            subject to road_load_upper {c in comid_N1, s in seasons, y in years}:

              reduced_road_load_N1[c,s,y] <= baseloads_N1[c,s,y,'road'];


subject to road_load_lower {c in comid_N1, s in seasons, y in years}:
    reduced_road_load_N1[c,s,y] >=
        baseloads_N1[c,s,y,'road'] *
        (1 - sum {h in road_soil_groups, r in road_bmp}
              road_effic_N[c,s,y,h,r] * road_frac[c,h,r]);

            
            
            
            var reduced_point_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_septic_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

/* selector parameters for the diagnostic objective */
param S integer in seasons default 4;
param Y integer in years   default 15;

/* temporary objective: minimize the seasonal total load */
minimize min_total_load2:   sum {c in comid_N1} inc_storage_load_N1[c, 4,15];
  

subject to calc_red_ag_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_ag_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'ag'] * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a]));

  
    subject to calc_red_graz_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_graz_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'graz'] * (1 - sum {g in graz_bmp}(graz_effic_N[c,g] * graz_frac[c,g]));

  
    subject to calc_red_urb_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_urb_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'urban'] * (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}(urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]));

      
    subject to road_removal_cap_N1{c in comid_N1, s in seasons, y in years}:
    sum {h in road_soil_groups, r in road_bmp}

        road_effic_N[c,s,y,h,r] * road_frac[c,h,r] <= 1;

  
    subject to calc_red_road_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_road_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'road'] * (1 - sum{h in road_soil_groups, r in road_bmp}(road_effic_N[c,s,y,h,r] * road_frac[c,h,r]));
 
    
    subject to calc_red_point_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_point_load_N1[c,s,y] = 
 
        (baseloads_N1[c,s,y,'point'] + 0)  * (1 - sum{p in point_bmp}(point_effic_N[c,p] * point_dec[c,p]));

          
    subject to calc_red_septic_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_septic_load_N1[c,s,y] =
0;

          
    subject to calc_riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years}:
          riparian_reduction_load_N1[c,s,y] =  
          sum {b in ripbuf_bmp}

        ripbuf_length[c,b] * riparianremoval_N1[c,s,y,b];
          #*

          # (
          #   reduced_ag_load_N1[c,s,y] / riparianload_N1[c,s,y,'riparian']

          #   +

          #     (1 - sum {d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}

          #      urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u])

          #   * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag'])

          #   / riparianload_N1[c,s,y,'riparian']

          # );

  
      subject to calc_no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years}:

          no_storage_NPSload_N1[c,s,y] =
          baseloads_N1[c,s,y,'other'] +
          reduced_ag_load_N1[c,s,y] + 
          reduced_urb_load_N1[c,s,y] +   
          reduced_road_load_N1[c,s,y] +
          reduced_point_load_N1[c,s,y] +
          reduced_septic_load_N1[c,s,y] -
          riparian_reduction_load_N1[c,s,y];
 
          
      subject to calc_red_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_storage_load_N1[c,s,y] =

        if transfer_coefficients_N1[c,s,y,'notrib'] = 1 then
 
          (no_storage_NPSload_N1[c,s,y] * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s = first(seasons) then

          if y = first(years) then
            baseloads_N1[c,s,y,'storage']

          else if y != first(years) then

            (no_storage_NPSload_N1[c,4,y-1] 
            * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 & s != first(seasons) then

          (no_storage_NPSload_N1[c,s-1,y] 
* transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff']);

    
    subject to calc_inc_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      inc_storage_load_N1[c,s,y] =

        reduced_storage_load_N1[c,s,y] + 
        reduced_ag_load_N1[c,s,y] + 
        reduced_urb_load_N1[c,s,y] +   
        reduced_road_load_N1[c,s,y] +
        reduced_point_load_N1[c,s,y] +
        reduced_septic_load_N1[c,s,y] -
        riparian_reduction_load_N1[c,s,y];

    
subject to riparian_loads_N1 {c in comid_N1, s in seasons, y in years}:
sum {b in ripbuf_bmp} ripbuf_length[c, b] * riparianremoval_N1[c,s,y,b] <= 
 
            (baseloads_N1[c,s,y,'ag'] 
 
            * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a])) 

            + (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} 

              (urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]))
 
            * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag']));

subject to urban_frac_min2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u] * urbanBMP_bin[c,u];
    subject to ag_frac_min2 {c in comid_all, a in ag_bmp}:
ag_frac[c,a] >= ag_frac_min[a] * ag_bmp_implementationpotential[c,a] * agBMP_bin[c,a];
    subject to graz_frac_min2{c in comid_all,g in graz_bmp}:
graz_frac[c,g] >= graz_frac_min[g] * grazBMP_bin[c,g];

#    subject to road_frac_min2{c in comid_all, h in road_soil_groups,r in road_bmp}:
# road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND replacement
  subject to road_frac_min2 {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND added Aggregate min area per BMP (recommended) 
  subject to road_treat_min {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] * road_area[c,h,'road'] >= roadBMP_minarea * roadBMP_bin[c,r];
    
subject to ag_treat_min {c in comid_all, a in ag_bmp}:
ag_frac[c,a] * area[c,'ag'] >= agBMP_minarea * agBMP_bin[c,a];

subject to graz_treat_min {c in comid_all, g in graz_bmp}:
graz_frac[c,g] * area[c,'graz'] >= grazBMP_minarea * grazBMP_bin[c,g];

subject to urban_treat_min {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] * urban_area[c,d,n,'urban'] >= urbanBMP_minarea * urbanBMP_bin[c,u];
  
subject to ag_frac_const {c in comid_all, a in ag_bmp}:
ag_frac[c,a] <= agBMP_bin[c,a];

subject to graz_frac_const {c in comid_all, g in graz_bmp}:
graz_frac[c,g] <= grazBMP_bin[c,g];
  
subject to urban_frac_const {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] <= urbanBMP_bin[c,u];

#ND added missing 6/3/26;
subject to road_frac_const {c in comid_all, h in road_soil_groups, r in road_bmp}:
    road_frac[c,h,r] <= roadBMP_bin[c,r];

subject to ag_frac_limit {c in comid_all}: 
sum {a in ag_bmp} ag_frac[c,a] <= 1;
# prevents multiple BMPs being implemented on the same area

subject to graz_frac_limit {c in comid_all}: 
sum {g in graz_bmp} graz_frac[c,g] <= 1;
# prevents multiple BMPs being implemented on the same area

#subject to urban_frac_limit {c in comid_all}: 
#sum {u in urban_bmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,u] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - drop
# Per-subarea (d,n) constraint
 subject to urban_frac_limit2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups}:
  sum {u in urban_bmp} urban_frac[c,d,n,u] <= 1;

subject to road_frac_limit {c in comid_all}: 
sum {r in road_bmp, h in road_soil_groups} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - try dropping this because not updated during bootstraps
# Per-soil-group constraint
# subject to road_frac_limit2 {c in comid_all, h in road_soil_groups}:
#  sum {r in road_bmp} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same sub-area

subject to point_dec_limit {c in comid_all}: 
sum {p in point_bmp} point_dec[c,p] <= 1;
# limits each WWTP to one upgrade

subject to total_banks {c in comid_all}:
sum {b in ripbuf_bmp} ripbuf_length[c,b] <=  
   unbuffered_banklength[c,'Forested_Buffer']; #ND 7/8/2026 changed from max
  


subject to roads_and_parkinglots {c in comid_all}:
sum{up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,up] <= max {up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} 
   urban_bmp_implementationpotential[c,d,n,up];


subject to tiledrains {c in comid_all}:
sum{agti in ag_tilebmp} ag_frac[c, agti] <= max {agti in ag_tilebmp}
   ag_bmp_implementationpotential[c,agti];

