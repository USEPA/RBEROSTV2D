#STmodel_seasonal.mod
      
set comid_all :=
{'24274325','24274327','24274329','24274331','24274361','24274363','24274365','24274367','24274369','24274371','24274373','24274375','24274377','24274379','24274381','24274383','24274385','24274387','24274389','24274391','24274393','24274395','24274397','24274399','24274401','24274403','24274405','24274407','24274409','24274411','24274413','24274415','24274417','24274419','24274421','24274423','24274425','24274427','24274429','24274431','24274433','24274435','24274437','24274439','24274441','24274443','24274445','24274447','24274449','24274451','24274453','24274455','24274457','24274459','24274461','24274463','24274465','24274467','24274469','24274471','24274473','24274475','24274477','24274479','24274481','24274483','24274485','24274487','24274489','24274491','24274493','24274495','24274497','24274499','24274501','24274503','24274505','24274507','24274509','24274511','24274513','24274515','24274517','24274519','24274521','24274523','24274525','24274527','24274529','24274531','24274533','24274535','24274537','24274539','24274541','24274543','24274545','24274547','24274549','24274551','24274553','24274555','24274557','24274559','24274561','24274563','24274565','24274567','24274569','24274571','24274573','24274575','24274577','24274579','24274581','24274583','24274585','24274587','24274589','24274591','24274593','24274595','24274597','24274599','24274601','24274603','24274605','24274607','24274609','24274611','24274613','24274615','24274617','24274619','24274621','24274623','24274625','24274627','24274629','24274631','24274633','24274635','24274637','24274639','24274641','24274643','24274645','24274647','24274649','24274651','24274653','24274655','24274657','24274659','24274661','24274663','24274665','24274667','24274669','24274671','24274673','24274675','24274677','24274679','24274681','24274683','24274685','24274687','24274689','24274691','24274693','24274695','24274697','24274699','24274701','24274703','24274705','24274707','24274709','24274711','24274713','24274715','24274717','24274719','24274721','24274723','24274725','24274727','24274729','24274731','24274733','24274735','24274737','24274739','24274741','24274743','24274745','24274747','24274749','24274751','24274753','24274755','24274757','24274759','24274761','24274763','24274765','24274767','24274769','24274771','24274773','24274777','24274779','24274781','24274783','24274785','24274787','24274789','24274791','24274793','24274795','24274797','24274799','24274801','24274803','24274805','24274807','24274809','24274811','24274813','24274815','24274817','24274819','24274821','24274823','24274825','24274827','24274829','24274831','24274833','24274835','24274837','24274839','24274841','24274843','24274845','24274847','24274849','24274851','24274853','24274855','24274857','24274859','24274861','24274863','24274865','24274867','24274869','24274871','24274873','24274875','24274877','24274879','24274881','24274883','24274885','24274889','24274897','24274899','24274901','24274903','24274905','24274907','24274909','24274911','24274913','24274915','24274917','24274919','24274921','24274923','24274925','24274927','24274929','24274931','24274933','24274935','24274937','24274939','24274941','24274943','24274953','24274955','24274957','24274959','24274961','24274963','24274965','24274967','24274969','24274971','24274973','24274975','24274977','24274979','24274981','24274983','24274985','24274987','24274989','24274991','24274993','24274995','24274997','24274999','24275001','24275003','24275005','24275007','24275009','24275011','24275013','24275015','24275017','24275019','24275021','24275023','24275025','24275027','24275029','24275031','24275033','24275035','24275037','24275039','24275041','24275043','24275045','24275047','24275049','24275051','24275057','24275059','24275061','24275063','24275067','24275069','24275071','24275075','24275077','24275079','24275083','24275085','24275087','24275089','24275091','24275093','24275095','24275097','24275099','24275101','24275103','24275107','24275109','24275111','24275113','24275117','24275119','24275121','24275125','24275127','24275129','24275131','24275133','24275135','24275139','24275143','24275145','24275147','24275149','24275155','24275157','24275161','24275163','24275165','24275167','24275169','24275171','24275173','24275175','24275177','24275181','24275185','24275187','24275189','24275191','24275193','24275195','24275197','24275199','24275201','24275203','24275205','24275207','24275209','24275211','24275213','24275215','24275217','24275219','24275221','24275223','24275225','24275227','24275229','24275231','24275233','24275235','24275237','24275239','24275241','24275243','24275245','24275247','24275249','24275251','24275253','24275255','24275257','24275259','24275261','24275263','24275265','24275267','24275269','24275271','24275273','24275275','24275277','24275279','24275281','24275283','24275285','24275287','24275289','24275291','24275293','24275295','24275297','24275299','24275301','24275303','24275305','24275307','24275309','24275311','24275313','24275315','24275317','24275319','24275321','24275323','24275325','24275327','24275329','24275331','24275333','24275335','24275337','24275339','24275341','24275343','24275345','24275347','24275349','24275351','24275353','24275355','24275357','24275361','24275363','24275365','24275367','24275369','24275371','24275373','24275375','24275377','24275379','24275381','24275383','24275385','24275387','24275389','24275391','24275393','24275395','24275397','24275399','24275401','24275403','24275405','24275407','24275409','24275411','24275417','24275421','24275429','24275431','24275433','24275435','24275437','24275439','24275441','24275443','24275445','24275449','24275451','24275453','24275455','24275457','24275459','24275461','24275463','24275465','24275467','24275469','24275471','24275473','24275475','24275477','24275479','24275481','24275483','24275485','24275487','24275489','24275493','24275495','24275497','24275499','24275501','24275503','24275505','24275507','24275509','24275511','24275513','24275515','24275517','24275519','24275521','24275523','24275525','24275527','24275529','24275531','24275533','24275535','24275537','24275539','24275541','24275543','24275545','24275547','24275549','24275551','24275553','24275557','24275559','24275561','24275563','24275565','24275567','24275569','24275573','24275575','24275577','24275579','24275589','24275593','24275595','24275597','24275599','24275601','24275607','24275613','24275617','24275619','24275621','24275625','24275627','24275633','24275635','24275637','24275639','24275641','24275643','24275735','24275737','24275741'};

set comid_all_N within comid_all := {'24274325','24274327','24274329','24274331','24274361','24274363','24274365','24274367','24274369','24274371','24274373','24274375','24274377','24274379','24274381','24274383','24274385','24274387','24274389','24274391','24274393','24274395','24274397','24274399','24274401','24274403','24274405','24274407','24274409','24274411','24274413','24274415','24274417','24274419','24274421','24274423','24274425','24274427','24274429','24274431','24274433','24274435','24274437','24274439','24274441','24274443','24274445','24274447','24274449','24274451','24274453','24274455','24274457','24274459','24274461','24274463','24274465','24274467','24274469','24274471','24274473','24274475','24274477','24274479','24274481','24274483','24274485','24274487','24274489','24274491','24274493','24274495','24274497','24274499','24274501','24274503','24274505','24274507','24274509','24274511','24274513','24274515','24274517','24274519','24274521','24274523','24274525','24274527','24274529','24274531','24274533','24274535','24274537','24274539','24274541','24274543','24274545','24274547','24274549','24274551','24274553','24274555','24274557','24274559','24274561','24274563','24274565','24274567','24274569','24274571','24274573','24274575','24274577','24274579','24274581','24274583','24274585','24274587','24274589','24274591','24274593','24274595','24274597','24274599','24274601','24274603','24274605','24274607','24274609','24274611','24274613','24274615','24274617','24274619','24274621','24274623','24274625','24274627','24274629','24274631','24274633','24274635','24274637','24274639','24274641','24274643','24274645','24274647','24274649','24274651','24274653','24274655','24274657','24274659','24274661','24274663','24274665','24274667','24274669','24274671','24274673','24274675','24274677','24274679','24274681','24274683','24274685','24274687','24274689','24274691','24274693','24274695','24274697','24274699','24274701','24274703','24274705','24274707','24274709','24274711','24274713','24274715','24274717','24274719','24274721','24274723','24274725','24274727','24274729','24274731','24274733','24274735','24274737','24274739','24274741','24274743','24274745','24274747','24274749','24274751','24274753','24274755','24274757','24274759','24274761','24274763','24274765','24274767','24274769','24274771','24274773','24274777','24274779','24274781','24274783','24274785','24274787','24274789','24274791','24274793','24274795','24274797','24274799','24274801','24274803','24274805','24274807','24274809','24274811','24274813','24274815','24274817','24274819','24274821','24274823','24274825','24274827','24274829','24274831','24274833','24274835','24274837','24274839','24274841','24274843','24274845','24274847','24274849','24274851','24274853','24274855','24274857','24274859','24274861','24274863','24274865','24274867','24274869','24274871','24274873','24274875','24274877','24274879','24274881','24274883','24274885','24274889','24274897','24274899','24274901','24274903','24274905','24274907','24274909','24274911','24274913','24274915','24274917','24274919','24274921','24274923','24274925','24274927','24274929','24274931','24274933','24274935','24274937','24274939','24274941','24274943','24274953','24274955','24274957','24274959','24274961','24274963','24274965','24274967','24274969','24274971','24274973','24274975','24274977','24274979','24274981','24274983','24274985','24274987','24274989','24274991','24274993','24274995','24274997','24274999','24275001','24275003','24275005','24275007','24275009','24275011','24275013','24275015','24275017','24275019','24275021','24275023','24275025','24275027','24275029','24275031','24275033','24275035','24275037','24275039','24275041','24275043','24275045','24275047','24275049','24275051','24275057','24275059','24275061','24275063','24275067','24275069','24275071','24275075','24275077','24275079','24275083','24275085','24275087','24275089','24275091','24275093','24275095','24275097','24275099','24275101','24275103','24275107','24275109','24275111','24275113','24275117','24275119','24275121','24275125','24275127','24275129','24275131','24275133','24275135','24275139','24275143','24275145','24275147','24275149','24275155','24275157','24275161','24275163','24275165','24275167','24275169','24275171','24275173','24275175','24275177','24275181','24275185','24275187','24275189','24275191','24275193','24275195','24275197','24275199','24275201','24275203','24275205','24275207','24275209','24275211','24275213','24275215','24275217','24275219','24275221','24275223','24275225','24275227','24275229','24275231','24275233','24275235','24275237','24275239','24275241','24275243','24275245','24275247','24275249','24275251','24275253','24275255','24275257','24275259','24275261','24275263','24275265','24275267','24275269','24275271','24275273','24275275','24275277','24275279','24275281','24275283','24275285','24275287','24275289','24275291','24275293','24275295','24275297','24275299','24275301','24275303','24275305','24275307','24275309','24275311','24275313','24275315','24275317','24275319','24275321','24275323','24275325','24275327','24275329','24275331','24275333','24275335','24275337','24275339','24275341','24275343','24275345','24275347','24275349','24275351','24275353','24275355','24275357','24275361','24275363','24275365','24275367','24275369','24275371','24275373','24275375','24275377','24275379','24275381','24275383','24275385','24275387','24275389','24275391','24275393','24275395','24275397','24275399','24275401','24275403','24275405','24275407','24275409','24275411','24275417','24275421','24275429','24275431','24275433','24275435','24275437','24275439','24275441','24275443','24275445','24275449','24275451','24275453','24275455','24275457','24275459','24275461','24275463','24275465','24275467','24275469','24275471','24275473','24275475','24275477','24275479','24275481','24275483','24275485','24275487','24275489','24275493','24275495','24275497','24275499','24275501','24275503','24275505','24275507','24275509','24275511','24275513','24275515','24275517','24275519','24275521','24275523','24275525','24275527','24275529','24275531','24275533','24275535','24275537','24275539','24275541','24275543','24275545','24275547','24275549','24275551','24275553','24275557','24275559','24275561','24275563','24275565','24275567','24275569','24275573','24275575','24275577','24275579','24275589','24275593','24275595','24275597','24275599','24275601','24275607','24275613','24275617','24275619','24275621','24275625','24275627','24275633','24275635','24275637','24275639','24275641','24275643','24275735','24275737','24275741'};

set comid_all_P within comid_all := {};

set comid_N1 within comid_all_N := {'24274325','24274327','24274329','24274331','24274361','24274363','24274365','24274367','24274369','24274371','24274373','24274375','24274377','24274379','24274381','24274383','24274385','24274387','24274389','24274391','24274393','24274395','24274397','24274399','24274401','24274403','24274405','24274407','24274409','24274411','24274413','24274415','24274417','24274419','24274421','24274423','24274425','24274427','24274429','24274431','24274433','24274435','24274437','24274439','24274441','24274443','24274445','24274447','24274449','24274451','24274453','24274455','24274457','24274459','24274461','24274463','24274465','24274467','24274469','24274471','24274473','24274475','24274477','24274479','24274481','24274483','24274485','24274487','24274489','24274491','24274493','24274495','24274497','24274499','24274501','24274503','24274505','24274507','24274509','24274511','24274513','24274515','24274517','24274519','24274521','24274523','24274525','24274527','24274529','24274531','24274533','24274535','24274537','24274539','24274541','24274543','24274545','24274547','24274549','24274551','24274553','24274555','24274557','24274559','24274561','24274563','24274565','24274567','24274569','24274571','24274573','24274575','24274577','24274579','24274581','24274583','24274585','24274587','24274589','24274591','24274593','24274595','24274597','24274599','24274601','24274603','24274605','24274607','24274609','24274611','24274613','24274615','24274617','24274619','24274621','24274623','24274625','24274627','24274629','24274631','24274633','24274635','24274637','24274639','24274641','24274643','24274645','24274647','24274649','24274651','24274653','24274655','24274657','24274659','24274661','24274663','24274665','24274667','24274669','24274671','24274673','24274675','24274677','24274679','24274681','24274683','24274685','24274687','24274689','24274691','24274693','24274695','24274697','24274699','24274701','24274703','24274705','24274707','24274709','24274711','24274713','24274715','24274717','24274719','24274721','24274723','24274725','24274727','24274729','24274731','24274733','24274735','24274737','24274739','24274741','24274743','24274745','24274747','24274749','24274751','24274753','24274755','24274757','24274759','24274761','24274763','24274765','24274767','24274769','24274771','24274773','24274777','24274779','24274781','24274783','24274785','24274787','24274789','24274791','24274793','24274795','24274797','24274799','24274801','24274803','24274805','24274807','24274809','24274811','24274813','24274815','24274817','24274819','24274821','24274823','24274825','24274827','24274829','24274831','24274833','24274835','24274837','24274839','24274841','24274843','24274845','24274847','24274849','24274851','24274853','24274855','24274857','24274859','24274861','24274863','24274865','24274867','24274869','24274871','24274873','24274875','24274877','24274879','24274881','24274883','24274885','24274889','24274897','24274899','24274901','24274903','24274905','24274907','24274909','24274911','24274913','24274915','24274917','24274919','24274921','24274923','24274925','24274927','24274929','24274931','24274933','24274935','24274937','24274939','24274941','24274943','24274953','24274955','24274957','24274959','24274961','24274963','24274965','24274967','24274969','24274971','24274973','24274975','24274977','24274979','24274981','24274983','24274985','24274987','24274989','24274991','24274993','24274995','24274997','24274999','24275001','24275003','24275005','24275007','24275009','24275011','24275013','24275015','24275017','24275019','24275021','24275023','24275025','24275027','24275029','24275031','24275033','24275035','24275037','24275039','24275041','24275043','24275045','24275047','24275049','24275051','24275057','24275059','24275061','24275063','24275067','24275069','24275071','24275075','24275077','24275079','24275083','24275085','24275087','24275089','24275091','24275093','24275095','24275097','24275099','24275101','24275103','24275107','24275109','24275111','24275113','24275117','24275119','24275121','24275125','24275127','24275129','24275131','24275133','24275135','24275139','24275143','24275145','24275147','24275149','24275155','24275157','24275161','24275163','24275165','24275167','24275169','24275171','24275173','24275175','24275177','24275181','24275185','24275187','24275189','24275191','24275193','24275195','24275197','24275199','24275201','24275203','24275205','24275207','24275209','24275211','24275213','24275215','24275217','24275219','24275221','24275223','24275225','24275227','24275229','24275231','24275233','24275235','24275237','24275239','24275241','24275243','24275245','24275247','24275249','24275251','24275253','24275255','24275257','24275259','24275261','24275263','24275265','24275267','24275269','24275271','24275273','24275275','24275277','24275279','24275281','24275283','24275285','24275287','24275289','24275291','24275293','24275295','24275297','24275299','24275301','24275303','24275305','24275307','24275309','24275311','24275313','24275315','24275317','24275319','24275321','24275323','24275325','24275327','24275329','24275331','24275333','24275335','24275337','24275339','24275341','24275343','24275345','24275347','24275349','24275351','24275353','24275355','24275357','24275361','24275363','24275365','24275367','24275369','24275371','24275373','24275375','24275377','24275379','24275381','24275383','24275385','24275387','24275389','24275391','24275393','24275395','24275397','24275399','24275401','24275403','24275405','24275407','24275409','24275411','24275417','24275421','24275429','24275431','24275433','24275435','24275437','24275439','24275441','24275443','24275445','24275449','24275451','24275453','24275455','24275457','24275459','24275461','24275463','24275465','24275467','24275469','24275471','24275473','24275475','24275477','24275479','24275481','24275483','24275485','24275487','24275489','24275493','24275495','24275497','24275499','24275501','24275503','24275505','24275507','24275509','24275511','24275513','24275515','24275517','24275519','24275521','24275523','24275525','24275527','24275529','24275531','24275533','24275535','24275537','24275539','24275541','24275543','24275545','24275547','24275549','24275551','24275553','24275557','24275559','24275561','24275563','24275565','24275567','24275569','24275573','24275575','24275577','24275579','24275589','24275593','24275595','24275597','24275599','24275601','24275607','24275613','24275617','24275619','24275621','24275625','24275627','24275633','24275635','24275637','24275639','24275641','24275643','24275735','24275737','24275741'};

set comid_P1 within comid_all_P := {};

set seasons := 1..4 ordered; 

set years := 6..7 ordered;

set urban_land_uses := {'UIDU','URHD','URLD','URMD'};

set urban_soil_groups := {'A','B','C','D'};

set road_soil_groups := {'A','B','C','D'};


set urban_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Green_Roof','Infiltration_Basin','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set urban_pervbmp within urban_bmp :=
{'Porous_Pavement_w_UD'};

set road_bmp :=
{'Extended_Dry_Detention_Basin','Grass_Swale_w_D','Infiltration_Basin','Infiltration_Chamber','Infiltration_Trench','Permeable_Pavement','Porous_Pavement_w_UD','Sand_Filter_w_UD','Wet_Pond'};

set ag_bmp :=
{'Conservation','Contour_Farming','Fert_75','Fert_90','Filterstrip','MIN_TILL','Terrace_Waterway','Terrace_Only','Waterway_Only','Grade_Stabilization','Diversion','Cover_Crops','Drainage_Management','Manure_Injection'};

set ag_tilebmp within ag_bmp :=
{'Drainage_Management'};

set septic_bmp :=
{'none'};

set graz_bmp :=
{'Offsite_Water'};

set ripbuf_bmp :=
{'Grassed_Buffer','Forested_Buffer'};

set point_bmp :=
{'C','C_F','FOURBDP_M','FOURBDP_M_C_F','MLE','MLE_C','C_M','M','SBR','SBR_C','SBR_C_F','SBR_DNF_C_F_M','SBR_DNF_M','FOURBDP_MBR_M','FOURBDP_MBR_M_C','MLE_MBR','MLE_MBR_C'};

set loads_all :=
{'point', 'urban', 'road', 'ag', 'septic', 'graz', 'storage', 'other'};
  
set area_sub :=
{'ag', 'graz'};
set urban_area_sub :=
{'urban'};
set road_area_sub :=
{'road'};

set transfer_types := {'coeff', 'notrib'};

set loads_riparian := 
 {'riparian'};

set limits := 
 {'limits'};

set total_load := 
 {'total_load'};

set other_loads := 
 {'other_load'};

set septic_bmp_totals := 
 {'total_parcels'};

param baseloads_N1 {comid_N1, seasons, years, loads_all} >= 0;
param riparianload_N1 {comid_N1, seasons, years, loads_riparian} >= 0;

param septic_bmp_implementationpotential {comid_all_N, septic_bmp} >= 0;
param septic_bmp_implementationtotal {comid_all_N, septic_bmp_totals} >= 0;

param area {comid_all, area_sub} >=0;
    
param urban_area {comid_all, urban_land_uses, urban_soil_groups, urban_area_sub} >=0;
param road_area {comid_all, road_soil_groups, road_area_sub} >=0;
param urban_bmp_implementationpotential {comid_all, urban_land_uses, urban_soil_groups, urban_bmp} >= 0;
# ND 7/20/26 added
param road_bmp_implementationpotential {comid_all, road_soil_groups, road_bmp} >= 0;
param ag_bmp_implementationpotential {comid_all, ag_bmp} >= 0;
param unbuffered_banklength {comid_all, ripbuf_bmp} >= 0;
param total_banklength {comid_all} >= 0;

param ag_costs_capital {comid_all, ag_bmp};
param ag_costs_operations {comid_all, ag_bmp};
param graz_costs_capital {comid_all, graz_bmp};
param graz_costs_operations {comid_all, graz_bmp};
param point_costs_capital {comid_all, point_bmp};
param point_costs_operations {comid_all, point_bmp};
param urban_costs_capital {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param urban_costs_operations {comid_all, urban_land_uses, urban_soil_groups, urban_bmp};
param road_costs_capital {comid_all, road_soil_groups, road_bmp};
param road_costs_operations {comid_all, road_soil_groups, road_bmp};
param ripbuf_costs_capital {comid_all, ripbuf_bmp};
param ripbuf_costs_operations {comid_all, ripbuf_bmp};

param septic_costs_capital {comid_all_N, septic_bmp} >= 0;
param septic_costs_operations {comid_all_N, septic_bmp} >= 0;



param ag_effic_N {comid_all_N, ag_bmp};
param graz_effic_N {comid_all_N, graz_bmp};
param point_effic_N {comid_all_N, point_bmp};
param urban_effic_N {comid_all_N, seasons, years, urban_land_uses, urban_soil_groups, urban_bmp};
param road_effic_N {comid_all_N, seasons, years, road_soil_groups, road_bmp};
param septic_effic_N {comid_all_N, septic_bmp};

param riparianremoval_N1 {c in comid_N1, s in seasons, y in years, b in ripbuf_bmp};
param loads_lim_N1 {seasons, years, limits} >= 0;


param transfer_coefficients_N1 {comid_N1, seasons, years, transfer_types};

param total_load_N1 {s in seasons, y in years, total_load} >= 0;


param agcost_frac >=0;
    
param agBMP_minarea;
param grazBMP_minarea;
param urbanBMP_minarea;
param roadBMP_minarea;

param urban_frac_min {urban_bmp} >=0, <= 1;
param urban_frac_max {u in urban_bmp} >= urban_frac_min[u], <= 1;
param road_frac_min {road_bmp} >=0, <= 1;
param road_frac_max {r in road_bmp} >= road_frac_min[r], <= 1;
param ag_frac_min {ag_bmp} >= 0, <= 1;
param ag_frac_max {a in ag_bmp} >= ag_frac_min[a], <= 1;
param graz_frac_min {graz_bmp} >= 0, <= 1;
param graz_frac_max {g in graz_bmp} >= graz_frac_min[g], <= 1;
param ripbuf_frac_min {ripbuf_bmp} >= 0, <= 1;
param ripbuf_frac_max {b in ripbuf_bmp} >= ripbuf_frac_min[b], <= 1;
  
param ps_coef {c in comid_all, p in point_bmp} := (point_costs_capital[c, p] + 
    point_costs_operations[c, p]);
param urban_coef {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} := urban_area[c,d,n,'urban'] * 
  (urban_costs_capital[c,d,n,u] + urban_costs_operations[c,d,n,u]) ;
param road_coef {c in comid_all, h in road_soil_groups, r in road_bmp} := road_area[c,h,'road'] * 
  (road_costs_capital[c,h,r] + road_costs_operations[c,h,r]) ;
param ag_coef {c in comid_all,  a in ag_bmp} := agcost_frac * area[c,'ag'] * 
  (ag_costs_capital[c,a] + ag_costs_operations[c,a]) ;

param graz_coef {c in comid_all, g in graz_bmp} := agcost_frac * area[c,'graz'] * 
  (graz_costs_capital[c,g] + graz_costs_operations[c,g]) ;
param ripbuf_coef {c in comid_all, b in ripbuf_bmp} := 
  agcost_frac * (ripbuf_costs_capital[c, b] + ripbuf_costs_operations[c, b]);
  
var agBMP_bin {comid_all, ag_bmp} binary;
var grazBMP_bin {comid_all, graz_bmp} binary;
var urbanBMP_bin {comid_all, urban_bmp} binary;
var roadBMP_bin {comid_all, road_bmp} binary;

var point_dec {c in comid_all, p in point_bmp} binary;
# correct unbounded fraction variables - AI solution created NEOS error  
var urban_frac {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}
  >= 0, <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u];
#  := 0; # default is 0 so not needed; 
#    >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u],  
#    <= urban_frac_max[u] * urban_bmp_implementationpotential[c,d,n,u],
#    :=0;
var ag_frac {c in comid_all, a in ag_bmp}
   >= 0,
   <= ag_frac_max[a] * ag_bmp_implementationpotential[c,a];
#   := 0
#    >= ag_frac_min[a] * ag_bmp_implementationpotential[c, a],  
#    <= ag_frac_max[a] * ag_bmp_implementationpotential[c, a],
#    :=0;
# ND 7/20/26 Added road_bmp_implementationpotential
var road_frac {c in comid_all, h in road_soil_groups, r in road_bmp}
  >= 0, 
  <= road_frac_max[r] * road_bmp_implementationpotential[c,h,r];
#  := 0;  
#   >= road_frac_min[r],
#   <= road_frac_max[r],
#   :=0;
var graz_frac {c in comid_all, g in graz_bmp}
  >= 0,
  <= graz_frac_max[g];
#  := 0;
#   >= graz_frac_min[g],
#   <= graz_frac_max[g],
#   :=0;
var ripbuf_length {c in comid_all, b in ripbuf_bmp} 
   >= 0, 
   <= unbuffered_banklength[c, b] * ripbuf_frac_max[b];
#   := 0;
   

var inc_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;
var no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_ag_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_graz_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_urb_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_road_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            subject to road_load_upper {c in comid_N1, s in seasons, y in years}:

              reduced_road_load_N1[c,s,y] <= baseloads_N1[c,s,y,'road'];


subject to road_load_lower {c in comid_N1, s in seasons, y in years}:
    reduced_road_load_N1[c,s,y] >=
        baseloads_N1[c,s,y,'road'] *
        (1 - sum {h in road_soil_groups, r in road_bmp}
              road_effic_N[c,s,y,h,r] * road_frac[c,h,r]);

            
            
            
            var reduced_point_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_septic_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var reduced_storage_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

            var riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years} >= 0;

minimize cost: sum {c in comid_all, p in point_bmp} (ps_coef[c,p] * point_dec[c,p]) +
sum {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} (urban_coef[c,d,n,u] * urban_frac[c,d,n,u]) +
sum {c in comid_all, h in road_soil_groups, r in road_bmp} (road_coef[c,h,r] * road_frac[c,h,r]) +
sum {c in comid_all, a in ag_bmp} (ag_coef[c,a] * ag_frac[c,a]) +
sum {c in comid_all, g in graz_bmp} (graz_coef[c,g] * graz_frac[c,g]) +
 

sum {c in comid_all, b in ripbuf_bmp} (ripbuf_coef[c, b] * ripbuf_length[c, b]);
subject to calc_red_ag_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_ag_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'ag'] * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a]));

  
    subject to calc_red_graz_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_graz_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'graz'] * (1 - sum {g in graz_bmp}(graz_effic_N[c,g] * graz_frac[c,g]));

  
    subject to calc_red_urb_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_urb_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'urban'] * (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}(urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]));

      
    subject to road_removal_cap_N1{c in comid_N1, s in seasons, y in years}:
    sum {h in road_soil_groups, r in road_bmp}

        road_effic_N[c,s,y,h,r] * road_frac[c,h,r] <= 1;

  
    subject to calc_red_road_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_road_load_N1[c,s,y] =

      baseloads_N1[c,s,y,'road'] * (1 - sum{h in road_soil_groups, r in road_bmp}(road_effic_N[c,s,y,h,r] * road_frac[c,h,r]));
 
    
    subject to calc_red_point_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_point_load_N1[c,s,y] = 
 
        (baseloads_N1[c,s,y,'point'] + 0)  * (1 - sum{p in point_bmp}(point_effic_N[c,p] * point_dec[c,p]));

          
    subject to calc_red_septic_load_N1{c in comid_N1, s in seasons, y in years}:

        reduced_septic_load_N1[c,s,y] =
0;

          
    subject to calc_riparian_reduction_load_N1{c in comid_N1, s in seasons, y in years}:
          riparian_reduction_load_N1[c,s,y] =  
          sum {b in ripbuf_bmp}

        ripbuf_length[c,b] * riparianremoval_N1[c,s,y,b];
          #*

          # (
          #   reduced_ag_load_N1[c,s,y] / riparianload_N1[c,s,y,'riparian']

          #   +

          #     (1 - sum {d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}

          #      urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u])

          #   * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag'])

          #   / riparianload_N1[c,s,y,'riparian']

          # );

  
      subject to calc_no_storage_NPSload_N1{c in comid_N1, s in seasons, y in years}:

          no_storage_NPSload_N1[c,s,y] =
          baseloads_N1[c,s,y,'other'] +
          reduced_ag_load_N1[c,s,y] + 
          reduced_urb_load_N1[c,s,y] +   
          reduced_road_load_N1[c,s,y] +
          reduced_point_load_N1[c,s,y] +
          reduced_septic_load_N1[c,s,y] -
          riparian_reduction_load_N1[c,s,y];
 
          
      subject to calc_red_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      reduced_storage_load_N1[c,s,y] =

        if transfer_coefficients_N1[c,s,y,'notrib'] = 1 then
 
          (no_storage_NPSload_N1[c,s,y] * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 && s = first(seasons) then

          if y = first(years) then
            baseloads_N1[c,s,y,'storage']

          else if y != first(years) then

            (no_storage_NPSload_N1[c,4,y-1] 
            * transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff'])

        else if transfer_coefficients_N1[c,s,y,'notrib'] = 0 && s != first(seasons) then

          (no_storage_NPSload_N1[c,s-1,y] 
* transfer_coefficients_N1[c,s,y,'coeff']) / (1 - transfer_coefficients_N1[c,s,y,'coeff']);

    
    subject to calc_inc_storage_load_N1{c in comid_N1, s in seasons, y in years}:

      inc_storage_load_N1[c,s,y] =

        reduced_storage_load_N1[c,s,y] + 
        reduced_ag_load_N1[c,s,y] + 
        reduced_urb_load_N1[c,s,y] +   
        reduced_road_load_N1[c,s,y] +
        reduced_point_load_N1[c,s,y] +
        reduced_septic_load_N1[c,s,y] -
        riparian_reduction_load_N1[c,s,y];

    
subject to total_loads_N1{s in seasons, y in years}:
sum{c in comid_N1} (inc_storage_load_N1[c,s,7]) <= loads_lim_N1[s,7,'limits'];

subject to riparian_loads_N1 {c in comid_N1, s in seasons, y in years}:
sum {b in ripbuf_bmp} ripbuf_length[c, b] * riparianremoval_N1[c,s,y,b] <= 
 
            (baseloads_N1[c,s,y,'ag'] 
 
            * (1 - sum {a in ag_bmp}(ag_effic_N[c,a] * ag_frac[c,a])) 

            + (1 - sum{d in urban_land_uses, n in urban_soil_groups, u in urban_bmp} 

              (urban_effic_N[c,s,y,d,n,u] * urban_frac[c,d,n,u]))
 
            * (riparianload_N1[c,s,y,'riparian'] - baseloads_N1[c,s,y,'ag']));

subject to urban_frac_min2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] >= urban_frac_min[u] * urban_bmp_implementationpotential[c,d,n,u] * urbanBMP_bin[c,u];
    subject to ag_frac_min2 {c in comid_all, a in ag_bmp}:
ag_frac[c,a] >= ag_frac_min[a] * ag_bmp_implementationpotential[c,a] * agBMP_bin[c,a];
    subject to graz_frac_min2{c in comid_all,g in graz_bmp}:
graz_frac[c,g] >= graz_frac_min[g] * grazBMP_bin[c,g];

#    subject to road_frac_min2{c in comid_all, h in road_soil_groups,r in road_bmp}:
# road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND replacement
  subject to road_frac_min2 {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] >= road_frac_min[r] * roadBMP_bin[c,r];

# ND added Aggregate min area per BMP (recommended) 
  subject to road_treat_min {c in comid_all, r in road_bmp}:
sum {h in road_soil_groups} road_frac[c,h,r] * road_area[c,h,'road'] >= roadBMP_minarea * roadBMP_bin[c,r];
    
subject to ag_treat_min {c in comid_all, a in ag_bmp}:
ag_frac[c,a] * area[c,'ag'] >= agBMP_minarea * agBMP_bin[c,a];

subject to graz_treat_min {c in comid_all, g in graz_bmp}:
graz_frac[c,g] * area[c,'graz'] >= grazBMP_minarea * grazBMP_bin[c,g];

subject to urban_treat_min {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] * urban_area[c,d,n,'urban'] >= urbanBMP_minarea * urbanBMP_bin[c,u];
  
subject to ag_frac_const {c in comid_all, a in ag_bmp}:
ag_frac[c,a] <= agBMP_bin[c,a];

subject to graz_frac_const {c in comid_all, g in graz_bmp}:
graz_frac[c,g] <= grazBMP_bin[c,g];
  
subject to urban_frac_const {c in comid_all, d in urban_land_uses, n in urban_soil_groups, u in urban_bmp}:
urban_frac[c,d,n,u] <= urbanBMP_bin[c,u];

#ND added missing 6/3/26;
subject to road_frac_const {c in comid_all, h in road_soil_groups, r in road_bmp}:
    road_frac[c,h,r] <= roadBMP_bin[c,r];

subject to ag_frac_limit {c in comid_all}: 
sum {a in ag_bmp} ag_frac[c,a] <= 1;
# prevents multiple BMPs being implemented on the same area

subject to graz_frac_limit {c in comid_all}: 
sum {g in graz_bmp} graz_frac[c,g] <= 1;
# prevents multiple BMPs being implemented on the same area

#subject to urban_frac_limit {c in comid_all}: 
#sum {u in urban_bmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,u] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - drop
# Per-subarea (d,n) constraint
 subject to urban_frac_limit2 {c in comid_all, d in urban_land_uses, n in urban_soil_groups}:
  sum {u in urban_bmp} urban_frac[c,d,n,u] <= 1;

subject to road_frac_limit {c in comid_all}: 
sum {r in road_bmp, h in road_soil_groups} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same area

# ND substitute - try dropping this because not updated during bootstraps
# Per-soil-group constraint
# subject to road_frac_limit2 {c in comid_all, h in road_soil_groups}:
#  sum {r in road_bmp} road_frac[c,h,r] <= 1;
# prevents multiple BMPs being implemented on the same sub-area

subject to point_dec_limit {c in comid_all}: 
sum {p in point_bmp} point_dec[c,p] <= 1;
# limits each WWTP to one upgrade

subject to total_banks {c in comid_all}:
sum {b in ripbuf_bmp} ripbuf_length[c,b] <=  
   unbuffered_banklength[c,'Forested_Buffer']; #ND 7/8/2026 changed from max
  


subject to roads_and_parkinglots {c in comid_all}:
sum{up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} urban_frac[c,d,n,up] <= max {up in urban_pervbmp, d in urban_land_uses, n in urban_soil_groups} 
   urban_bmp_implementationpotential[c,d,n,up];


subject to tiledrains {c in comid_all}:
sum{agti in ag_tilebmp} ag_frac[c, agti] <= max {agti in ag_tilebmp}
   ag_bmp_implementationpotential[c,agti];

